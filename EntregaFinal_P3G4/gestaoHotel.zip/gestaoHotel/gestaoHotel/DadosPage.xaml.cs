﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for DadosPage.xaml
    /// </summary>
    public partial class DadosPage : MetroWindow
    {
        private SqlConnection con;

        public DadosPage()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            FillDatagridHoteis();
        }
              
        private void FillDatagridHoteis()
        {         
            string search_id;
            try
            {   // Get hotel id
                int ind = (int)Application.Current.Resources["ApplicationScopeResource"];
                search_id = ind.ToString();
            }
            catch (Exception)
            {
                return;
            }
            
            ID_Hoteis.Text = search_id;            
            string CmdString = "SELECT * FROM udf_Hotel_DataGrid(@idHotel)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idHotel", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Hotel_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            Nome_Hoteis.Text = dr["nome"].ToString();
            morada_hotel.Text = dr["localizacao"].ToString();
            codpost_hotel.Text = dr["codigoPostal"].ToString();
            cl_hotel.Text = dr["classificacao"].ToString();
            //
            Random rnd = new Random();
            int price = rnd.Next(50, 150);
            preco.Text = price.ToString();
            preco_final.Text = preco.Text;
            preco_inicio.Text = preco.Text;
        }

        private void Reservar(object sender, RoutedEventArgs e)
        {

            string CmdString = "sp_AddCliente";
            SqlCommand cmd_cliente = new SqlCommand(CmdString, con);
            cmd_cliente.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_cliente.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(datanasc.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@Pnome", P_nome.Text);
            cmd_cliente.Parameters.AddWithValue("@Unome", U_nome.Text);
            cmd_cliente.Parameters.AddWithValue("@email", Mail.Text);
            cmd_cliente.Parameters.AddWithValue("@endereco", morada.Text);
            cmd_cliente.Parameters.AddWithValue("@codigoPostal", codpost.Text);
            cmd_cliente.Parameters.AddWithValue("@nrTelefone", Tele.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do cliente não pode estar por preencher!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_cliente.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("O cliente foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
            /* ------------------------------------------------------------------------- */
            string CmdString2 = "sp_AddReserva";
            SqlCommand cmd_res = new SqlCommand(CmdString2, con);
            cmd_res.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_res.Parameters.AddWithValue("@dataInicio", Convert.ToDateTime(data_checkin.Text));
                cmd_res.Parameters.AddWithValue("@dataFim", Convert.ToDateTime(data_checkout.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@numPessoas", num_pessoas.Text);
            //
            con.Open();
            string cli = "SELECT MAX(id) FROM gestaoHotel.Cliente;";
            SqlCommand cmd3 = new SqlCommand(cli, con);
            String res = cmd3.ExecuteScalar().ToString();
            cmd_res.Parameters.AddWithValue("@cliente", res);
            //
            cmd_res.Parameters.AddWithValue("@tipo", DBNull.Value);
            cmd_res.Parameters.AddWithValue("@quantidade", DBNull.Value);
            //
            string func = "SELECT MAX(nrFuncionario) FROM gestaoHotel.Recepcionista;";
            SqlCommand cmd = new SqlCommand(func, con);
            String res2 = cmd.ExecuteScalar().ToString();
            cmd_res.Parameters.AddWithValue("@recepcionista", res2);
            //
            string room = "SELECT MAX(idQuarto) FROM gestaoHotel.Quarto;";
            SqlCommand cmd2 = new SqlCommand(room, con);
            String res3 = cmd2.ExecuteScalar().ToString();
            cmd_res.Parameters.AddWithValue("@quarto", res3);
            //
            string pension = "SA";
            if (Pensao.SelectedIndex==0)
                pension = "SA";
            else if(Pensao.SelectedIndex ==1 )
                pension = "APA";
            else
                pension = "PC";
            //
            cmd_res.Parameters.AddWithValue("@tipoPensao", pension);
            con.Close();
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_res.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("A reserva foi adicionada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
            /* ------------------------------------------------------------------------- */
        }


        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */

        private void Button_Login(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.ShowDialog();
        }

        private void ComboBox_Loaded(object sender, RoutedEventArgs e)
        {
            List<string> data = new List<string>();
            data.Add("Single");
            data.Add("Double");
            data.Add("Twin");
            data.Add("Mini-Suite");
            data.Add("Suite");
            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;
            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;
            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void ComboBox_LoadedQuartos(object sender, RoutedEventArgs e)
        {
            List<string> data = new List<string>();
            data.Add("1");
            data.Add("2");
            data.Add("3");
            data.Add("4");
            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;
            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;
            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void ComboBox_LoadedPeople(object sender, RoutedEventArgs e)
        {
            List<string> data = new List<string>();
            data.Add("1");
            data.Add("2");
            data.Add("3");
            data.Add("4");

            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;
            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;
            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void ComboBox_LoadedPensao(object sender, RoutedEventArgs e)
        {
            List<string> data = new List<string>();
            data.Add("Só Alojamento");
            data.Add("Pequeno-Almoço");
            data.Add("Pensão Completa");

            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;
            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;
            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (Check_in.Text=="" || Check_out.Text=="")
            {
                MessageBox.Show("Tem de selecionar uma data!!");
                return;
            }
            this.tabcontrol.SelectedIndex = 1;
        }

        private void DP_SelectedDateCI(object sender, RoutedEventArgs e)
        {
            data_checkin.Text = Check_in.Text;
        }

        private void DP_SelectedDateCO(object sender, RoutedEventArgs e)
        {
            data_checkout.Text = Check_out.Text;
        }

        private void DP_SelectedDateNQ(object sender, RoutedEventArgs e)
        {
            num_quartos.Text = n_Q.Text;
        }

        private void DP_SelectedDateQ(object sender, RoutedEventArgs e)
        {
            tipo_quarto.Text = TipoQuarto.Text;
        }

        private void DP_SelectedDateP(object sender, RoutedEventArgs e)
        {
            tipo_pensao.Text = Pensao.Text;
        }

        private void DP_SelectedPeople(object sender, RoutedEventArgs e)
        {
            num_pessoas.Text = CB_pessoas.Text;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int i;
            if (!int.TryParse(Tele.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            DateTime temp;
            if (!DateTime.TryParse(datanasc.Text, out temp))
            {
                MessageBox.Show("Data não válida!!");
                return;
            }

            if (RB_Sexo_M.IsChecked== false && RB_Sexo_F.IsChecked==false)
            {
                MessageBox.Show("Tem de selecionar o sexo!!");
                return;
            }

            if (P_nome.Text=="" || U_nome.Text=="" || datanasc.Text=="" || Mail.Text==""
                || Tele.Text == "" || morada.Text == "" || codpost.Text == "")
            {
                MessageBox.Show("Tem de preencher toda a informação!!");
                return;
            }
            this.tabcontrol.SelectedIndex = 2;
        }

        private void DP_SelectedDateNome(object sender, RoutedEventArgs e)
        {
            name_SR.Text = P_nome.Text + " " + U_nome.Text;
        }

        private void DP_SelectedEmail(object sender, RoutedEventArgs e)
        {
            Email_3.Text = Mail.Text;
        }

        private void DP_SelectedDateCI2(object sender, RoutedEventArgs e)
        {
            DCI_3.Text = Check_in.Text;
        }

        private void DP_SelectedDateCO2(object sender, RoutedEventArgs e)
        {
            DCO_3.Text = Check_out.Text;
        }

        private void DP_SelectedDateQ2(object sender, RoutedEventArgs e)
        {
            TQ_3.Text = TipoQuarto.Text;
        }
        private void DP_SelectedDateP2(object sender, RoutedEventArgs e)
        {
            TP_3.Text = Pensao.Text;
        }

        private void DP_SelectedDateNQ3(object sender, RoutedEventArgs e)
        {
            NPesssoas_3.Text = num_pessoas.Text;
        }

        private void DP_SelectedDateNQQ(object sender, RoutedEventArgs e)
        {
            NQ_3.Text = n_Q.Text;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.tabcontrol.SelectedIndex = 1;
        }

        private void P_Checked(object sender, RoutedEventArgs e)
        {
            paypal.Visibility = Visibility.Visible;
            grid.Visibility = Visibility.Hidden;
        }

        private void Cartao_Checked(object sender, RoutedEventArgs e)
        {
            grid.Visibility = Visibility.Visible;
            paypal.Visibility = Visibility.Hidden;
        }

        private void ComboBox_LoadedCartao(object sender, RoutedEventArgs e)
        {
            List<string> data = new List<string>();
            data.Add("American Express");
            data.Add("Visa");
            data.Add("MasterCard");

            // ... Get the ComboBox reference.
            var cartao = sender as ComboBox;
            // ... Assign the ItemsSource to the List.
            cartao.ItemsSource = data;
            // ... Make the first item selected.
            cartao.SelectedIndex = 0;
        }

        private void Home3_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            this.Close();
            m.ShowDialog();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }
    }
}