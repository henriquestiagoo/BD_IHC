﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Gestao.xaml
    /// </summary>
    public partial class Gestao : MetroWindow
    {
        public Gestao()
        {
            InitializeComponent();
        }

        private void Button_Home(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Hoteis(object sender, RoutedEventArgs e)
        {
            Hotel hotel = new Hotel();
            this.Close();
            hotel.ShowDialog();
        }

        private void Button_Pessoa(object sender, RoutedEventArgs e)
        {
            Pessoa pessoa = new Pessoa();
            this.Close();
            pessoa.ShowDialog();
        }

        private void Button_Reserva(object sender, RoutedEventArgs e)
        {
            Reserva res = new Reserva();
            this.Close();
            res.ShowDialog();
        }

        private void Button_Temporada(object sender, RoutedEventArgs e)
        {
            Temporada tem = new Temporada();
            this.Close();
            tem.ShowDialog();
        }
    }
}
