﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Destinos.xaml
    /// </summary>
    public partial class Destinos : MetroWindow
    {
        private SqlConnection con;

        public Destinos()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            FillDatagridStats();        
        }

        /* ##################################################################################################### */
        /*                                                 Stats                                                 */
        /* ##################################################################################################### */

        private void FillDatagridStats()
        {
            string CmdString = "SELECT * FROM udf_Hotel_Stats_Nr_hoteis()";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Hotel_Stats_Nr_Hoteis");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            Nr_Hoteis.Text = dr["numero"].ToString();
            //
            CmdString = "SELECT * FROM udf_Hotel_Stats_Clientes_Hotel()";
            cmd = new SqlCommand(CmdString, con);
            sda = new SqlDataAdapter(cmd);
            dt = new DataTable("nr_clientes_hotel");
            sda.Fill(dt);
            nr_clientes_hotel_grid.ItemsSource = dt.DefaultView;
            // gerentes Hoteis
            CmdString = "SELECT * FROM udf_Hotel_Stats_Gerentes_Hotel()";
            cmd = new SqlCommand(CmdString, con);
            sda = new SqlDataAdapter(cmd);
            dt = new DataTable("gerentes_Hotel");
            sda.Fill(dt);
            gers_hoteis_grid.ItemsSource = dt.DefaultView;
            //
            SqlCommand cmd2 = new SqlCommand();
            cmd2.CommandText = "select gestaoHotel.HotelComMaisClientes()";
            cmd2.CommandType = CommandType.Text;
            cmd2.Connection = con;
            SqlDataReader value = cmd2.ExecuteReader();
            string treatment = "";
            while (value.Read())
            {
                treatment += value[0].ToString();
            }
            Hotel_Clientes.Text = treatment;
            con.Close();
            con.Open();
            cmd2.CommandText = "select gestaoHotel.HotelComMaisReservas()";
            cmd2.CommandType = CommandType.Text;
            cmd2.Connection = con;
            value = cmd2.ExecuteReader();
            treatment = "";
            while (value.Read())
            {
                treatment += value[0].ToString();
            }

            hotel_reservas.Text = treatment;
            con.Close();
            con.Open();
            cmd2.CommandText = "select gestaoHotel.HotelComMaisFunc()";
            cmd2.CommandType = CommandType.Text;
            cmd2.Connection = con;
            value = cmd2.ExecuteReader();
            treatment = "";
            while (value.Read())
            {
                treatment += value[0].ToString();
            }

            funcs_hotel.Text = treatment;
            con.Close();
            con.Open();
            cmd2.CommandText = "select gestaoHotel.HotelComGerenteMaisBemPago()";
            cmd2.CommandType = CommandType.Text;
            cmd2.Connection = con;
            value = cmd2.ExecuteReader();
            treatment = "";
            while (value.Read())
            {
                treatment += value[0].ToString();
            }
            gerente_max.Text = treatment;
            con.Close();
        }

        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */

        private void Button_Login(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            //this.NavigateTo(login);
            login.ShowDialog();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            this.Close();
            m.ShowDialog();
        }
    }
}

