﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Pessoa.xaml
    /// </summary>
    public partial class Pessoa : MetroWindow
    {
        private SqlConnection con;

        public Pessoa()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            FillDatagridClientes();
            ComboBox_Fill();
            FillDatagridFuncs();
    }


        /* ##################################################################################################### */
        /*                                                 Clientes                                              */
        /* ##################################################################################################### */

        private void FillDatagridClientes()
        {
            string CmdString = "SELECT * FROM udf_Cliente_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Cliente");
            sda.Fill(dt);
            clientes_grid.ItemsSource = dt.DefaultView;
        }

        private void clientes_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)clientes_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_Clientes.Text = search_id;
            string CmdString = "SELECT * FROM udf_Cliente_DataGrid(@id)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@id", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Clientes_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ID_Clientes.Text = dr["id"].ToString();
            Pnome_Clientes.Text = dr["Pnome"].ToString();
            Unome_Clientes.Text = dr["Unome"].ToString();
            Email_Clientes.Text = dr["email"].ToString();
            DataNasc_Clientes.Text = dr["dataNasc"].ToString();
            Morada_Clientes.Text = dr["endereco"].ToString();
            CodPost_Clientes.Text = dr["codigoPostal"].ToString();
            Telefone_Clientes.Text = dr["nrTelefone"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["sexo"].ToString() == "M")
                RB_Sexo_M.IsChecked = true;
            else 
                RB_Sexo_F.IsChecked = true;
            /* --------------------------------------------------------- */
        }


        private void AdicionarCliente(object sender, RoutedEventArgs e)
        {
            // Validacoes
              if (Pnome_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Clientes.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Clientes.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Clientes.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            string CmdString = "sp_AddCliente";
            SqlCommand cmd_cliente = new SqlCommand(CmdString, con);
            cmd_cliente.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_cliente.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Clientes.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@Pnome", Pnome_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@Unome", Unome_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@email", Email_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@endereco", Morada_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@codigoPostal", CodPost_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@nrTelefone", Telefone_Clientes.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do cliente não pode estar por preencher!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_cliente.ExecuteNonQuery();
                con.Close();
                FillDatagridClientes();
                MessageBox.Show("O cliente foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarCliente(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Clientes.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Clientes.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Clientes.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Clientes.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            string CmdString = "sp_UpdateCliente";
            SqlCommand cmd_cliente = new SqlCommand(CmdString, con);
            cmd_cliente.CommandType = CommandType.StoredProcedure;
            cmd_cliente.Parameters.AddWithValue("@idPessoa", ID_Clientes.Text);
            try
            {
                cmd_cliente.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Clientes.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@Pnome", Pnome_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@Unome", Unome_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@email", Email_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@endereco", Morada_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@codigoPostal", CodPost_Clientes.Text);
            cmd_cliente.Parameters.AddWithValue("@nrTelefone", Telefone_Clientes.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do cliente não pode estar por preencher!");
                return;
            }
            cmd_cliente.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_cliente.ExecuteNonQuery();
                con.Close();
                FillDatagridClientes();
                MessageBox.Show("O cliente foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverCliente(object sender, RoutedEventArgs e)
        {
            if (ID_Clientes.Text == "" && Pnome_Clientes.Text == "" && Unome_Clientes.Text == ""
                && Email_Clientes.Text == "" && DataNasc_Clientes.Text == "" && Morada_Clientes.Text == "" && CodPost_Clientes.Text == ""
                && Telefone_Clientes.Text == "" && RB_Sexo_M.IsChecked == false && RB_Sexo_F.IsChecked == false)
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteCliente";
            SqlCommand cmd_rec = new SqlCommand(CmdString, con);
            cmd_rec.CommandType = CommandType.StoredProcedure;
            cmd_rec.Parameters.AddWithValue("@idPessoa", ID_Clientes.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_rec.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparClientes();
                    FillDatagridClientes();
                    /* ----------------------------- */
                    MessageBox.Show("O cliente foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /* ##################################################################################################### */
        /*                                                 Funcionarios                                          */
        /* ##################################################################################################### */


        private void ComboBox_Fill()
        {
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString2 = "SELECT DISTINCT idHotel FROM gestaoHotel.Hotel;";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Hotel_Func.Items.Contains(DR[0]))
                    ComboBox_Hotel_Func.Items.Add(DR[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
            string CmdString3 = "SELECT DISTINCT nrFuncionario FROM gestaoHotel.Recepcionista;";
            SqlCommand cmd3 = new SqlCommand(CmdString3, con);
            con.Open();
            SqlDataReader DR2 = cmd3.ExecuteReader();
            while (DR2.Read())
            {
                if (!ComboBox_RecSuperv_Func.Items.Contains(DR2[0]))
                    ComboBox_RecSuperv_Func.Items.Add(DR2[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
            string CmdString4 = "SELECT DISTINCT nrFuncionario FROM gestaoHotel.Empregado;";
            SqlCommand cmd4 = new SqlCommand(CmdString4, con);
            con.Open();
            SqlDataReader DR3 = cmd4.ExecuteReader();
            while (DR3.Read())
            {
                if (!ComboBox_EmpSuperv_Func.Items.Contains(DR3[0]))
                    ComboBox_EmpSuperv_Func.Items.Add(DR3[0]);
            }
            con.Close();
        }

        private void FillDatagridFuncs()
        {
            string CmdString = "SELECT * FROM udf_Func_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Funcionario");
            sda.Fill(dt);
            funcs_grid.ItemsSource = dt.DefaultView;   
        }

        private void funcs_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)funcs_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_Clientes.Text = search_id;
            string CmdString = "SELECT * FROM udf_Func_DataGrid(@id)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@id", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Func_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ID_Funcs.Text = dr["id"].ToString();
            Pnome_Func.Text = dr["Pnome"].ToString();
            Unome_Func.Text = dr["Unome"].ToString();
            Email_Func.Text = dr["email"].ToString();
            DataNasc_Func.Text = dr["dataNasc"].ToString();
            Morada_Func.Text = dr["endereco"].ToString();
            CodPost_Func.Text = dr["codigoPostal"].ToString();
            Telefone_Func.Text = dr["nrTelefone"].ToString();
            Salario_Funcs.Text = dr["salario"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["sexo"].ToString() == "M")
                RB_Sexo2_M.IsChecked = true;
            else
                RB_Sexo2_F.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Hotel
            ComboBox_Hotel_Func.Text = dr["hotel"].ToString();
        }

        /* ##################################################################################################### */
        /*                                             Recepcionista                                             */
        /* ##################################################################################################### */

        private void FillDatagridRecs()
        {
            string CmdString = "SELECT * FROM udf_Rec_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Recepcionista");
            sda.Fill(dt);
            rec_grid.ItemsSource = dt.DefaultView;
        }

        private void rec_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)rec_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_Clientes.Text = search_id;
            string CmdString = "SELECT * FROM udf_Rec_DataGrid(@id)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@id", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Recs_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ID_Funcs.Text = dr["id"].ToString();
            Pnome_Func.Text = dr["Pnome"].ToString();
            Unome_Func.Text = dr["Unome"].ToString();
            Email_Func.Text = dr["email"].ToString();
            DataNasc_Func.Text = dr["dataNasc"].ToString();
            Morada_Func.Text = dr["endereco"].ToString();
            CodPost_Func.Text = dr["codigoPostal"].ToString();
            Telefone_Func.Text = dr["nrTelefone"].ToString();
            Salario_Funcs.Text = dr["salario"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["sexo"].ToString() == "M")
                RB_Sexo2_M.IsChecked = true;
            else
                RB_Sexo2_F.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Hotel
            ComboBox_Hotel_Func.Text = dr["hotel"].ToString();
            // ComboBox SuperV
            ComboBox_RecSuperv_Func.Text = dr["supervisor"].ToString();
        }

  
        private void AdicionarRecepcionista(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_AddRec";
            SqlCommand cmd_rec = new SqlCommand(CmdString, con);
            cmd_rec.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_rec.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_rec.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_rec.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_rec.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_rec.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_rec.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            cmd_rec.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_RecSuperv_Func.SelectedIndex == -1)
            {
                cmd_rec.Parameters.AddWithValue("@supervisor", DBNull.Value);
            }
            else
                cmd_rec.Parameters.AddWithValue("@supervisor", ComboBox_RecSuperv_Func.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_rec.ExecuteNonQuery();
                con.Close();
                FillDatagridRecs();
                MessageBox.Show("O Recepcionista foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarRecepcionista(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_UpdateRec";
            SqlCommand cmd_rec = new SqlCommand(CmdString, con);
            cmd_rec.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_rec.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@idPessoa", ID_Funcs.Text);
            cmd_rec.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_rec.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_rec.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_rec.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_rec.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_rec.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            cmd_rec.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_rec.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_RecSuperv_Func.SelectedIndex == -1)
            {
                cmd_rec.Parameters.AddWithValue("@supervisor", DBNull.Value);
            }
            else
                cmd_rec.Parameters.AddWithValue("@supervisor", ComboBox_RecSuperv_Func.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_rec.ExecuteNonQuery();
                con.Close();
                FillDatagridRecs();
                MessageBox.Show("O Recepcionista foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }



        private void RemoverRecepcionista(object sender, RoutedEventArgs e)
        {
            if (ID_Funcs.Text == "" && Pnome_Func.Text == "" && Unome_Func.Text == ""
                && Email_Func.Text == "" && DataNasc_Func.Text == "" && Morada_Func.Text == "" && CodPost_Func.Text == ""
                && Telefone_Func.Text == "" && RB_Sexo2_M.IsChecked == false && RB_Sexo2_F.IsChecked == false
                && Salario_Funcs.Text=="" && ComboBox_Hotel_Func.Text=="" && ComboBox_RecSuperv_Func.Text=="")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteRec";
            SqlCommand cmd_rec = new SqlCommand(CmdString, con);
            cmd_rec.CommandType = CommandType.StoredProcedure;
            cmd_rec.Parameters.AddWithValue("@idPessoa", ID_Clientes.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_rec.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparFuncs();
                    FillDatagridRecs();
                    /* ----------------------------- */
                    MessageBox.Show("O recepcionista foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                             Empregados                                                */
        /* ##################################################################################################### */


        private void FillDatagridEmps()
        {
            string CmdString = "SELECT * FROM udf_Emp_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Empregado");
            sda.Fill(dt);
            emp_grid.ItemsSource = dt.DefaultView;
        }

        private void emp_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)emp_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_Clientes.Text = search_id;
            string CmdString = "SELECT * FROM udf_Emp_DataGrid(@id)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@id", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Emps_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ID_Funcs.Text = dr["id"].ToString();
            Pnome_Func.Text = dr["Pnome"].ToString();
            Unome_Func.Text = dr["Unome"].ToString();
            Email_Func.Text = dr["email"].ToString();
            DataNasc_Func.Text = dr["dataNasc"].ToString();
            Morada_Func.Text = dr["endereco"].ToString();
            CodPost_Func.Text = dr["codigoPostal"].ToString();
            Telefone_Func.Text = dr["nrTelefone"].ToString();
            Salario_Funcs.Text = dr["salario"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["sexo"].ToString() == "M")
                RB_Sexo2_M.IsChecked = true;
            else
                RB_Sexo2_F.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Hotel
            ComboBox_Hotel_Func.Text = dr["hotel"].ToString();
            // ComboBox SuperV
            ComboBox_EmpSuperv_Func.Text = dr["supervisor"].ToString();
        }


        private void AdicionarEmpregado(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_AddEmp";
            SqlCommand cmd_emp = new SqlCommand(CmdString, con);
            cmd_emp.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_emp.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_emp.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_emp.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_emp.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_emp.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_emp.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            cmd_emp.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_EmpSuperv_Func.SelectedIndex == -1)
            {
                cmd_emp.Parameters.AddWithValue("@supervisor", DBNull.Value);
            }
            else
                cmd_emp.Parameters.AddWithValue("@supervisor", ComboBox_EmpSuperv_Func.Text);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_emp.ExecuteNonQuery();
                con.Close();
                FillDatagridEmps();
                MessageBox.Show("O Empregado foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarEmpregado(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }


            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_UpdateEmp";
            SqlCommand cmd_emp = new SqlCommand(CmdString, con);
            cmd_emp.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_emp.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@idPessoa", ID_Funcs.Text);
            cmd_emp.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_emp.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_emp.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_emp.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_emp.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_emp.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            cmd_emp.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_emp.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_EmpSuperv_Func.SelectedIndex == -1)
            {
                cmd_emp.Parameters.AddWithValue("@supervisor", DBNull.Value);
            }
            else
                cmd_emp.Parameters.AddWithValue("@supervisor", ComboBox_EmpSuperv_Func.Text);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_emp.ExecuteNonQuery();
                con.Close();
                FillDatagridEmps();
                MessageBox.Show("O Empregado foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverEmpregado(object sender, RoutedEventArgs e)
        {
            if (ID_Funcs.Text == "" && Pnome_Func.Text == "" && Unome_Func.Text == ""
                && Email_Func.Text == "" && DataNasc_Func.Text == "" && Morada_Func.Text == "" && CodPost_Func.Text == ""
                && Telefone_Func.Text == "" && RB_Sexo2_M.IsChecked == false && RB_Sexo2_F.IsChecked == false
                && Salario_Funcs.Text == "" && ComboBox_Hotel_Func.Text == "" && ComboBox_EmpSuperv_Func.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteEmp";
            SqlCommand cmd_rec = new SqlCommand(CmdString, con);
            cmd_rec.CommandType = CommandType.StoredProcedure;
            cmd_rec.Parameters.AddWithValue("@idPessoa", ID_Clientes.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_rec.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparFuncs();
                    FillDatagridEmps();
                    /* ----------------------------- */
                    MessageBox.Show("O empregado foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                             Gerentes                                                  */
        /* ##################################################################################################### */

        private void FillDatagridGers()
        {
            string CmdString = "SELECT * FROM udf_Ger_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Gerente");
            sda.Fill(dt);
            ger_grid.ItemsSource = dt.DefaultView;
        }

        private void ger_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)ger_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_Clientes.Text = search_id;
            string CmdString = "SELECT * FROM udf_Ger_DataGrid(@id)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@id", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Gers_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ID_Funcs.Text = dr["id"].ToString();
            Pnome_Func.Text = dr["Pnome"].ToString();
            Unome_Func.Text = dr["Unome"].ToString();
            Email_Func.Text = dr["email"].ToString();
            DataNasc_Func.Text = dr["dataNasc"].ToString();
            Morada_Func.Text = dr["endereco"].ToString();
            CodPost_Func.Text = dr["codigoPostal"].ToString();
            Telefone_Func.Text = dr["nrTelefone"].ToString();
            Salario_Funcs.Text = dr["salario"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["sexo"].ToString() == "M")
                RB_Sexo2_M.IsChecked = true;
            else
                RB_Sexo2_F.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Hotel
            ComboBox_Hotel_Func.Text = dr["hotel"].ToString();
        }


        private void AdicionarGerente(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_AddGer";
            SqlCommand cmd_ger = new SqlCommand(CmdString, con);
            cmd_ger.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_ger.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_ger.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_ger.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_ger.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_ger.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_ger.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            cmd_ger.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_ger.ExecuteNonQuery();
                con.Close();
                FillDatagridGers();
                MessageBox.Show("O Gerente foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarGerente(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Pnome_Func.Text.Length == 0)
            {
                MessageBox.Show("O primeiro nome não pode estar por preencher!");
                return;
            }

            if (Unome_Func.Text.Length == 0)
            {
                MessageBox.Show("O último nome não pode estar por preencher!");
                return;
            }

            if (Email_Func.Text.Length == 0)
            {
                MessageBox.Show("O email não pode estar por preencher!");
                return;
            }

            if (DataNasc_Func.Text.Length == 0)
            {
                MessageBox.Show("A data de Nascimento não pode estar por preencher!");
                return;
            }

            if (Morada_Func.Text.Length == 0)
            {
                MessageBox.Show("A morada não pode estar por preencher!");
                return;
            }

            if (CodPost_Func.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            if (Telefone_Func.Text.Length == 0)
            {
                MessageBox.Show("O telefone não pode estar por preencher!");
                return;
            }


            int i;
            if (!int.TryParse(Telefone_Func.Text, out i))
            {
                MessageBox.Show("O telefone tem de ser um número!");
                return;
            }

            if (Salario_Funcs.Text.Length == 0)
            {
                MessageBox.Show("O salário não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(Salario_Funcs.Text, out i))
            {
                MessageBox.Show("O salário tem de ser um número!");
                return;
            }

            string CmdString = "sp_UpdateGer";
            SqlCommand cmd_ger = new SqlCommand(CmdString, con);
            cmd_ger.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_ger.Parameters.AddWithValue("@dataNasc", Convert.ToDateTime(DataNasc_Func.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@idPessoa", ID_Funcs.Text);
            cmd_ger.Parameters.AddWithValue("@Pnome", Pnome_Func.Text);
            cmd_ger.Parameters.AddWithValue("@Unome", Unome_Func.Text);
            cmd_ger.Parameters.AddWithValue("@email", Email_Func.Text);
            cmd_ger.Parameters.AddWithValue("@endereco", Morada_Func.Text);
            cmd_ger.Parameters.AddWithValue("@codigoPostal", CodPost_Func.Text);
            cmd_ger.Parameters.AddWithValue("@nrTelefone", Telefone_Func.Text);
            cmd_ger.Parameters.AddWithValue("@salario", Salario_Funcs.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            char sex = 'M';
            if (RB_Sexo2_M.IsChecked == true)
                sex = 'M';
            else if (RB_Sexo2_F.IsChecked == true)
                sex = 'F';
            else { 
                MessageBox.Show("O sexo do funcionário não pode estar por preencher!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@sexo", sex);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Hotel;
            if (ComboBox_Hotel_Func.Text == "")
            {
                MessageBox.Show("O hotel não pode estar por preencher!");
                return;
            }
            cmd_ger.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Func.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_ger.ExecuteNonQuery();
                con.Close();
                FillDatagridGers();
                MessageBox.Show("O Gerente foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void RemoverGerente(object sender, RoutedEventArgs e)
        {
            if (ID_Funcs.Text == "" && Pnome_Func.Text == "" && Unome_Func.Text == ""
                && Email_Func.Text == "" && DataNasc_Func.Text == "" && Morada_Func.Text == "" && CodPost_Func.Text == ""
                && Telefone_Func.Text == "" && RB_Sexo2_M.IsChecked == false && RB_Sexo2_F.IsChecked == false)
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteGer";
            SqlCommand cmd_ger = new SqlCommand(CmdString, con);
            cmd_ger.CommandType = CommandType.StoredProcedure;
            cmd_ger.Parameters.AddWithValue("@idPessoa", ID_Funcs.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_ger.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparFuncs();
                    FillDatagridGers();
                    /* ----------------------------- */
                    MessageBox.Show("O Gerente foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }



        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */

        private void LimparBotoes()
        {
            //Limpar Botoes de adicionar, editar e remover
            B_limpar.Visibility = Visibility.Hidden;
            /* ------------------------------------------------- */
            B_AdicionarRec.Visibility = Visibility.Hidden;
            B_AdicionarEmp.Visibility = Visibility.Hidden;
            B_AdicionarGer.Visibility = Visibility.Hidden;
            /* ------------------------------------------------- */
            B_EditarRec.Visibility = Visibility.Hidden;
            B_EditarEmp.Visibility = Visibility.Hidden;
            B_EditarGer.Visibility = Visibility.Hidden;
            /* ------------------------------------------------- */
            B_RemoverRec.Visibility = Visibility.Hidden;
            B_RemoverEmp.Visibility = Visibility.Hidden;
            B_RemoverGer.Visibility = Visibility.Hidden;
        }

        private void LimparGrids()
        {
            funcs_grid.Visibility = Visibility.Hidden;
            rec_grid.Visibility = Visibility.Hidden;
            emp_grid.Visibility = Visibility.Hidden;
            ger_grid.Visibility = Visibility.Hidden;
        }

        private void ComboBox_Tipo_Func_Hidden()
        {
            /* ################################################# */
            //Right_Grid
            //ID1 - Recepcionista
            Rec_Super_Func.Visibility = Visibility.Hidden;
            ComboBox_RecSuperv_Func.Visibility = Visibility.Hidden;
            //ID2 - Empregado
            Emp_Super_Func.Visibility = Visibility.Hidden;
            ComboBox_EmpSuperv_Func.Visibility = Visibility.Hidden;
            /* ################################################# */
            //Grid Botoes_Servicos
            Grid.SetRow(Botoes_Servicos, 12);
        }

        private void ComboBox_Funcao_Func_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBox_Funcao_Func.SelectedIndex == 0) //Todos
            {
                ComboBox_Tipo_Func_Hidden();
                //Botoes
                Grid.SetRow(Botoes_Servicos, 12);
                Grid.SetRow(Botao_limpar, 12);
                /* ################################################# */
                LimparGrids();
                LimparBotoes();
                /* ################################################# */
                funcs_grid.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridFuncs();
            }
            else if (ComboBox_Funcao_Func.SelectedIndex == 1) //Recepcionista
            {   /* ################################################# */
                //Right_Grid
                ComboBox_Tipo_Func_Hidden();
                Rec_Super_Func.Visibility = Visibility.Visible;
                ComboBox_RecSuperv_Func.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 13);
                Grid.SetRow(Botao_limpar, 13);
                /* ################################################# */
                LimparGrids();
                LimparBotoes();
                /* ################################################# */
                rec_grid.Visibility = Visibility.Visible;
                B_limpar.Visibility = Visibility.Visible;
                B_AdicionarRec.Visibility = Visibility.Visible;
                B_EditarRec.Visibility = Visibility.Visible;
                B_RemoverRec.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridRecs();
            }
            else if (ComboBox_Funcao_Func.SelectedIndex == 2) //Empregado
            {   /* ################################################# */
                //Right_Grid
                ComboBox_Tipo_Func_Hidden();
                Emp_Super_Func.Visibility = Visibility.Visible;
                ComboBox_EmpSuperv_Func.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 13);
                Grid.SetRow(Botao_limpar, 13);
                /* ################################################# */
                LimparGrids();
                LimparBotoes();
                /* ################################################# */
                emp_grid.Visibility = Visibility.Visible;
                B_limpar.Visibility = Visibility.Visible;
                B_AdicionarEmp.Visibility = Visibility.Visible;
                B_EditarEmp.Visibility = Visibility.Visible;
                B_RemoverEmp.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridEmps();
            }
            else if (ComboBox_Funcao_Func.SelectedIndex == 3) //Gerente
            {
                /* ################################################# */
                //Right_Grid
                ComboBox_Tipo_Func_Hidden();
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 12);
                Grid.SetRow(Botao_limpar, 12);
                /* ################################################# */
                LimparGrids();
                LimparBotoes();
                /* ################################################# */
                ger_grid.Visibility = Visibility.Visible;
                B_limpar.Visibility = Visibility.Visible;
                B_AdicionarGer.Visibility = Visibility.Visible;
                B_EditarGer.Visibility = Visibility.Visible;
                B_RemoverGer.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridGers();
            }
        }

        private void LimparClientes_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            Pnome_Clientes.Text = "";
            Unome_Clientes.Text = "";
            Email_Clientes.Text = "";
            DataNasc_Clientes.Text = "";
            Morada_Clientes.Text = "";
            CodPost_Clientes.Text = "";
            Telefone_Clientes.Text = "";
            ID_Clientes.Text = "";
            /* -------------------------- */
            RB_Sexo_M.IsChecked = false;
            RB_Sexo_F.IsChecked = false;
        }

        private void LimparClientes()
        {
            //Limpar tudo
            Pnome_Clientes.Text = "";
            Unome_Clientes.Text = "";
            Email_Clientes.Text = "";
            DataNasc_Clientes.Text = "";
            Morada_Clientes.Text = "";
            CodPost_Clientes.Text = "";
            Telefone_Clientes.Text = "";
            ID_Clientes.Text = "";
            /* -------------------------- */
            RB_Sexo_M.IsChecked = false;
            RB_Sexo_F.IsChecked = false;
        }


        private void LimparFuncs_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            Pnome_Func.Text = "";
            Unome_Func.Text = "";
            Email_Func.Text = "";
            DataNasc_Func.Text = "";
            Morada_Func.Text = "";
            CodPost_Func.Text = "";
            Telefone_Func.Text = "";
            ID_Funcs.Text = "";
            Salario_Funcs.Text = "";
            /* -------------------------- */
            RB_Sexo2_M.IsChecked = false;
            RB_Sexo2_F.IsChecked = false;
            /* -------------------------- */
            ComboBox_Funcao_Func.SelectedIndex = -1;
            ComboBox_Hotel_Func.SelectedIndex = -1;
            ComboBox_RecSuperv_Func.SelectedIndex = -1;
            ComboBox_EmpSuperv_Func.SelectedIndex = -1;
        }

        private void LimparFuncs()
        {
            //Limpar tudo
            Pnome_Func.Text = "";
            Unome_Func.Text = "";
            Email_Func.Text = "";
            DataNasc_Func.Text = "";
            Morada_Func.Text = "";
            CodPost_Func.Text = "";
            Telefone_Func.Text = "";
            ID_Funcs.Text = "";
            Salario_Funcs.Text = "";
            /* -------------------------- */
            RB_Sexo2_M.IsChecked = false;
            RB_Sexo2_F.IsChecked = false;
            /* -------------------------- */
            ComboBox_Funcao_Func.SelectedIndex = -1;
            ComboBox_Hotel_Func.SelectedIndex = -1;
            ComboBox_RecSuperv_Func.SelectedIndex = -1;
            ComboBox_EmpSuperv_Func.SelectedIndex = -1;
        }


        private void Button_Home(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            Gestao g = new Gestao();
            this.Close();
            g.ShowDialog();
        }
    }
}
