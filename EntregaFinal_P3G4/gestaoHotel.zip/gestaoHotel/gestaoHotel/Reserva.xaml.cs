﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Reserva.xaml
    /// </summary>
    public partial class Reserva : MetroWindow
    {
        private SqlConnection con;

        public Reserva()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            FillDatagridReservas();
            FillDatagridPagamentos();
            FillComboBoxes();
            FillDatagridRestBar();
        }

        /* ##################################################################################################### */
        /*                                                 Reservas                                              */
        /* ##################################################################################################### */

        private void FillDatagridReservas()
        {
            string CmdString = "SELECT * FROM udf_Reserva_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Reserva");
            sda.Fill(dt);
            reservas_grid.ItemsSource = dt.DefaultView;
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString2 = "SELECT DISTINCT id FROM gestaoHotel.Cliente JOIN gestaoHotel.Pessoa ON id=idPessoa;";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Cliente_Reserva.Items.Contains(DR[0])) { 
                    ComboBox_Cliente_Reserva.Items.Add(DR[0]);
                }
            }
            con.Close();
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString3 = "SELECT DISTINCT tipo FROM gestaoHotel.Pensao;";
            SqlCommand cmd3 = new SqlCommand(CmdString3, con);
            con.Open();
            SqlDataReader DR2 = cmd3.ExecuteReader();
            while (DR2.Read())
            {
                if (!ComboBox_Pensao_Reserva.Items.Contains(DR2[0]))
                    ComboBox_Pensao_Reserva.Items.Add(DR2[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString5 = "SELECT DISTINCT id FROM gestaoHotel.Pessoa JOIN (gestaoHotel.Recepcionista JOIN gestaoHotel.Funcionario ON nrFuncionario=id) ON Funcionario.id = Pessoa.idPessoa; ";
            SqlCommand cmd5 = new SqlCommand(CmdString5, con);
            con.Open();
            SqlDataReader DR4 = cmd5.ExecuteReader();
            while (DR4.Read())
            {
                if (!ComboBox_Rec_Reserva.Items.Contains(DR4[0]))
                    ComboBox_Rec_Reserva.Items.Add(DR4[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString6 = "SELECT DISTINCT idQuarto FROM gestaoHotel.Quarto";
            SqlCommand cmd6 = new SqlCommand(CmdString6, con);
            con.Open();
            SqlDataReader DR5 = cmd6.ExecuteReader();
            while (DR5.Read())
            {
                if (!ComboBox_Quarto_Reserva.Items.Contains(DR5[0]))
                    ComboBox_Quarto_Reserva.Items.Add(DR5[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
        }

        private void reservas_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)reservas_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            TextBox_ID_Reserva.Text = search_id;
            string CmdString = "SELECT * FROM udf_Reserva_DataGrid(@idReserva)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idReserva", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Reserva_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            TextBox_ID_Reserva.Text = dr["idReserva"].ToString();
            var date = String.Format("{0:yyyy/MM/dd}", dr["dataInicio"]);
            DInicio_Reserva.Text = date;
            DFim_Reserva.Text = dr["dataFim"].ToString();
            Nr_Pessoas_Reserva.Text = dr["numPessoas"].ToString();
            TextBox_ID_Pag.Text = dr["pagamento"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["tipo"].ToString() == "single" || dr["tipo"].ToString() == "double" || dr["tipo"].ToString() == "twin"
                    || dr["tipo"].ToString() == "queen" || dr["tipo"].ToString() == "king")
                RB_CamaExtra_Sim.IsChecked = true;
            else
                RB_CamaExtra_Nao.IsChecked = true;
            /* --------------------------------------------------------- */
            ComboBox_Cliente_Reserva.Text = dr["cliente"].ToString();
            ComboBox_Rec_Reserva.Text = dr["recepcionista"].ToString();
            ComboBox_Pensao_Reserva.Text = dr["tipoPensao"].ToString();
            ComboBox_TipoCama_Reserva.Text = dr["tipo"].ToString();
            ComboBox_Quarto_Reserva.Text = dr["quarto"].ToString();
            /* --------------------------------------------------------- */
            if (dr["quantidade"].ToString() == "1")
                RB_QtCama_1.IsChecked = true;
            else if (dr["quantidade"].ToString() == "2")
                RB_QtCama_2.IsChecked = true;
            else if (dr["quantidade"].ToString() == "3")
                RB_QtCama_3.IsChecked = true;
            else {
                RB_QtCama_1.IsChecked = false;
                RB_QtCama_2.IsChecked = false;
                RB_QtCama_3.IsChecked = false;
            }
            /*
            if (RB_CamaExtra_Nao.IsChecked==true)
            {
                ComboBox_TipoCama_Reserva.SelectedIndex = -1;
                RB_QtCama_1.IsChecked = false;
                RB_QtCama_2.IsChecked = false;
                RB_QtCama_3.IsChecked = false;
            }
            */
        }

        private void AdicionarReserva(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (DInicio_Reserva.Text.Length == 0)
            {
                MessageBox.Show("A data de inicio não pode estar por preencher!");
                return;
            }

            if (DFim_Reserva.Text.Length == 0)
            {
                MessageBox.Show("A data de fim não pode estar por preencher!");
                return;
            }

            if (Nr_Pessoas_Reserva.Text.Length == 0)
            {
                MessageBox.Show("O número de pessoas não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_AddReserva";
            SqlCommand cmd_res = new SqlCommand(CmdString, con);
            cmd_res.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_res.Parameters.AddWithValue("@dataInicio", Convert.ToDateTime(DInicio_Reserva.Text));
                cmd_res.Parameters.AddWithValue("@dataFim", Convert.ToDateTime(DFim_Reserva.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@numPessoas", Nr_Pessoas_Reserva.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_Cliente_Reserva.Text == "")
            {
                MessageBox.Show("O cliente não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@cliente", ComboBox_Cliente_Reserva.Text);
            //
            if (ComboBox_Quarto_Reserva.Text == "")
            {
                MessageBox.Show("O quarto não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@quarto", ComboBox_Quarto_Reserva.Text);
            //
            if (ComboBox_Pensao_Reserva.Text == "")
            {
                MessageBox.Show("A pensão não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@tipoPensao", ComboBox_Pensao_Reserva.Text);
            //
            if (ComboBox_Rec_Reserva.Text == "")
            {
                MessageBox.Show("O recepcionista não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@recepcionista", ComboBox_Rec_Reserva.Text);
            //
            if(RB_CamaExtra_Sim.IsChecked == false && RB_CamaExtra_Nao.IsChecked == false)
            {
                MessageBox.Show("Deseja Cama extra ou não?");
                return;
            }

            // RadioButtons
            if (RB_CamaExtra_Nao.IsChecked == true) {
                cmd_res.Parameters.AddWithValue("@tipo", DBNull.Value);
                cmd_res.Parameters.AddWithValue("@quantidade", DBNull.Value);
            }
            else
            {
                // RadioButtons
                int qt=1;
                if (RB_QtCama_1.IsChecked == true)
                    qt = 1;
                else if (RB_QtCama_2.IsChecked == true)
                    qt = 2;
                else if (RB_QtCama_3.IsChecked == true)
                    qt = 3;
                else { 
                    MessageBox.Show("A quantidades de camas não pode estar por preencher!");
                    return;
                }
                cmd_res.Parameters.AddWithValue("@quantidade", qt);
                //
                if (ComboBox_TipoCama_Reserva.Text == "")
                {
                    MessageBox.Show("O tipo de cama não pode estar por preencher!");
                    return;
                }
                cmd_res.Parameters.AddWithValue("@tipo", ComboBox_TipoCama_Reserva.Text);
            }
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_res.ExecuteNonQuery();
                con.Close();
                FillDatagridReservas();
                MessageBox.Show("A reserva foi adicionada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarReserva(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (DInicio_Reserva.Text.Length == 0)
            {
                MessageBox.Show("A data de inicio não pode estar por preencher!");
                return;
            }

            if (DFim_Reserva.Text.Length == 0)
            {
                MessageBox.Show("A data de fim não pode estar por preencher!");
                return;
            }

            if (Nr_Pessoas_Reserva.Text.Length == 0)
            {
                MessageBox.Show("O número de pessoas não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_UpdateReserva";
            SqlCommand cmd_res = new SqlCommand(CmdString, con);
            cmd_res.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd_res.Parameters.AddWithValue("@dataInicio", Convert.ToDateTime(DInicio_Reserva.Text));
                cmd_res.Parameters.AddWithValue("@dataFim", Convert.ToDateTime(DFim_Reserva.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@idReserva", TextBox_ID_Reserva.Text);
            cmd_res.Parameters.AddWithValue("@numPessoas", Nr_Pessoas_Reserva.Text);
            /* ------------------------------------------------------------------------- */
            if (ComboBox_Cliente_Reserva.Text == "")
            {
                MessageBox.Show("O cliente não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@cliente", ComboBox_Cliente_Reserva.Text);
            //
            if (ComboBox_Quarto_Reserva.Text == "")
            {
                MessageBox.Show("O quarto não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@quarto", ComboBox_Quarto_Reserva.Text);
            //
            if (ComboBox_Pensao_Reserva.Text == "")
            {
                MessageBox.Show("A pensão não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@tipoPensao", ComboBox_Pensao_Reserva.Text);
            //
            if (ComboBox_Rec_Reserva.Text == "")
            {
                MessageBox.Show("O recepcionista não pode estar por preencher!");
                return;
            }
            cmd_res.Parameters.AddWithValue("@recepcionista", ComboBox_Rec_Reserva.Text);
            //
            if (RB_CamaExtra_Sim.IsChecked == false && RB_CamaExtra_Nao.IsChecked == false)
            {
                MessageBox.Show("Deseja Cama extra ou não?");
                return;
            }

            // RadioButtons
            if (RB_CamaExtra_Nao.IsChecked == true)
            {
                cmd_res.Parameters.AddWithValue("@tipo", ComboBox_TipoCama_Reserva.Text);
                cmd_res.Parameters.AddWithValue("@quantidade", "0");
            }
            else
            {
                if (ComboBox_TipoCama_Reserva.Text == "")
                {
                    MessageBox.Show("O tipo de cama não pode estar por preencher!");
                    return;
                }
                cmd_res.Parameters.AddWithValue("@tipo", ComboBox_TipoCama_Reserva.Text);
                // RadioButtons
                int qt = 1;
                if (RB_QtCama_1.IsChecked == true)
                    qt = 1;
                else if (RB_QtCama_2.IsChecked == true)
                    qt = 2;
                else if (RB_QtCama_3.IsChecked == true)
                    qt = 3;
                else {
                    MessageBox.Show("A quantidades de camas não pode estar por preencher!");
                    return;
                }
                cmd_res.Parameters.AddWithValue("@quantidade", qt);
                
            }
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_res.ExecuteNonQuery();
                con.Close();
                FillDatagridReservas();
                MessageBox.Show("A reserva foi editada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void RemoverReserva(object sender, RoutedEventArgs e)
        {
            if (DInicio_Reserva.Text == "" && DFim_Reserva.Text == "" && Nr_Pessoas_Reserva.Text == ""
                && ComboBox_Rec_Reserva.Text == "" && TextBox_ID_Reserva.Text=="" && TextBox_ID_Pag.Text=="" 
                && RB_CamaExtra_Sim.IsChecked == false && RB_CamaExtra_Nao.IsChecked == false 
                && ComboBox_TipoCama_Reserva.Text==""
                && RB_QtCama_1.IsChecked == false && RB_QtCama_2.IsChecked == false && RB_QtCama_3.IsChecked == false
                && ComboBox_Cliente_Reserva.Text == "" && ComboBox_Pensao_Reserva.Text == "" && ComboBox_Quarto_Reserva.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteReserva";
            SqlCommand cmd_restbar = new SqlCommand(CmdString, con);
            cmd_restbar.CommandType = CommandType.StoredProcedure;
            cmd_restbar.Parameters.AddWithValue("@idReserva", TextBox_ID_Reserva.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_restbar.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    limpar();
                    FillDatagridReservas();
                    /* ----------------------------- */
                    MessageBox.Show("A reserva foi removida com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                                 Pagamentos                                            */
        /* ##################################################################################################### */

        private void FillDatagridPagamentos()
        {
            string CmdString = "SELECT * FROM udf_Pagamento_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Pagamento");
            sda.Fill(dt);
            pagamentos_grid.ItemsSource = dt.DefaultView;
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString2 = "SELECT DISTINCT id FROM gestaoHotel.Pessoa JOIN (gestaoHotel.Recepcionista JOIN gestaoHotel.Funcionario ON nrFuncionario=id) ON Funcionario.id = Pessoa.idPessoa; ";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Rec_Pag.Items.Contains(DR[0]))
                    ComboBox_Rec_Pag.Items.Add(DR[0]);
            }
            con.Close();
            //
            string CmdString3 = "SELECT idReserva FROM gestaoHotel.Reserva WHERE pagamento is NULL; ";
            SqlCommand cmd3 = new SqlCommand(CmdString3, con);
            con.Open();
            SqlDataReader DR2 = cmd3.ExecuteReader();
            while (DR2.Read())
            {
                if (!ComboBox_Res_Pag.Items.Contains(DR2[0]))
                    ComboBox_Res_Pag.Items.Add(DR2[0]);
            }
            con.Close();
        }

        private void pagamentos_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)pagamentos_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ID_Pag.Text = search_id;
            string CmdString = "SELECT * FROM udf_Pagamento_DataGrid(@idPagamento)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idPagamento", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Pagamento_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            custototal_Pag.Text = Convert.ToDecimal(dr["custoTotal"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["dataPagamento"]);
            Data_Pag.Text = date;
            Metodo_Pag.Text = dr["metodo"].ToString();
            /* --------------------------------------------------------- */
            // ComboBox Recepcionista
            ComboBox_Rec_Pag.Text = dr["recepcionista"].ToString();
        }


        private void AdicionarPag(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (custototal_Pag.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(custototal_Pag.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Pag.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_AddPag";
            SqlCommand cmd_pag = new SqlCommand(CmdString, con);
            cmd_pag.CommandType = CommandType.StoredProcedure;
            cmd_pag.Parameters.AddWithValue("@custoTotal", Convert.ToDouble(custototal_Pag.Text));
            cmd_pag.Parameters.AddWithValue("@metodo", Metodo_Pag.Text);
            // ComboBox recepcionista
            if (ComboBox_Rec_Pag.Text == "")
            {
                MessageBox.Show("O id do recepcionista não pode estar por selecionar!");
                return;
            }
            cmd_pag.Parameters.AddWithValue("@recepcionista", ComboBox_Rec_Pag.Text);
            // ComboBox reserva
            if (ComboBox_Res_Pag.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_pag.Parameters.AddWithValue("@idReserva", ComboBox_Res_Pag.Text);

            try
            {
                cmd_pag.Parameters.AddWithValue("@dataPagamento", Convert.ToDateTime(Data_Pag.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }

            try
            {
                con.Open();
                cmd_pag.ExecuteNonQuery();
                con.Close();
                FillDatagridPagamentos();
                MessageBox.Show("O Pagamento foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarPag(object sender, RoutedEventArgs e)
        {
            // Validacoes
             if (custototal_Pag.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(custototal_Pag.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Pag.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_UpdatePag";
            SqlCommand cmd_pag = new SqlCommand(CmdString, con);
            cmd_pag.CommandType = CommandType.StoredProcedure;
            cmd_pag.Parameters.AddWithValue("@idPagamento", ID_Pag.Text);
            cmd_pag.Parameters.AddWithValue("@custoTotal", Convert.ToDouble(custototal_Pag.Text));
            cmd_pag.Parameters.AddWithValue("@metodo", Metodo_Pag.Text);
            // ComboBox
            if (ComboBox_Rec_Pag.Text == "")
            {
                MessageBox.Show("O id do recepcionista não pode estar por selecionar!");
                return;
            }
            cmd_pag.Parameters.AddWithValue("@recepcionista", ComboBox_Rec_Pag.Text);
            
            try
            {
                cmd_pag.Parameters.AddWithValue("@dataPagamento", Convert.ToDateTime(Data_Pag.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }

            try
            {
                con.Open();
                cmd_pag.ExecuteNonQuery();
                con.Close();
                FillDatagridPagamentos();
                MessageBox.Show("O Pagamento foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverPag(object sender, RoutedEventArgs e)
        {
            if (ID_Pag.Text == "" && custototal_Pag.Text == "" && Data_Pag.Text == ""
                && ComboBox_Rec_Pag.Text == "" && Metodo_Pag.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeletePag";
            SqlCommand cmd_pag = new SqlCommand(CmdString, con);
            cmd_pag.CommandType = CommandType.StoredProcedure;
            cmd_pag.Parameters.AddWithValue("@idPagamento", ID_Pag.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_pag.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridPagamentos();
                    /* ----------------------------- */
                    MessageBox.Show("O Pagamento foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                                 Servicos                                              */
        /* ##################################################################################################### */


        private void FillComboBoxes()
        {
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString2 = "SELECT DISTINCT idReserva FROM gestaoHotel.Reserva;";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Res_Servico.Items.Contains(DR[0]))
                    ComboBox_Res_Servico.Items.Add(DR[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString3 = "SELECT DISTINCT id FROM gestaoHotel.Funcionario JOIN gestaoHotel.Pessoa ON id=idPessoa;";
            SqlCommand cmd3 = new SqlCommand(CmdString3, con);
            con.Open();
            SqlDataReader DR2 = cmd3.ExecuteReader();
            while (DR2.Read())
            {
                if (!ComboBox_Func_Servico.Items.Contains(DR2[0]))
                    ComboBox_Func_Servico.Items.Add(DR2[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
        }


        /*___________________________________________________________________________________ */
        /*                                                                                    */
        /*                                      RestBar                                       */
        /*___________________________________________________________________________________ */


        private void FillDatagridRestBar()
        {
            string CmdString = "SELECT * FROM udf_RestBar_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("RestBar");
            sda.Fill(dt);
            restbar_grid.ItemsSource = dt.DefaultView;
        }


        private void restbar_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)restbar_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_servico.Text = search_id;
            string CmdString = "SELECT * FROM udf_RestBar_DataGrid(@idServico)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idServico", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("RestBar_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ComboBox_ID_Servico.SelectedIndex = 0;
            Custo_Servico.Text = Convert.ToDecimal(dr["custo"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["data"]);
            Data_Servico.Text = date;
            //
            TextBox_ID0.Text = dr["descricao"].ToString();
            /* --------------------------------------------------------- */
            // ComboBoxes
            ComboBox_Res_Servico.Text = dr["reserva"].ToString();
            ComboBox_Func_Servico.Text = dr["funcionario"].ToString();
            // RadioButtons Classificacao
            if (dr["tipo"].ToString() == "Restaurante" || dr["tipo"].ToString() == "restaurante" || dr["tipo"].ToString() == "RESTAURANTE")
                RB_Rest.IsChecked = true;
            else 
                RB_Bar.IsChecked = true;
            /* --------------------------------------------------------- */
        }


        private void AdicionarRestBar(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_AddRestBar";
            SqlCommand cmd_restbar = new SqlCommand(CmdString, con);
            cmd_restbar.CommandType = CommandType.StoredProcedure;
            cmd_restbar.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_restbar.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@descricao", TextBox_ID0.Text); 
            /* ------------------------------------------------------------------------- */
            // RadioButtons RestBar
            string t=null;
            if (RB_Rest.IsChecked == true)
                t = "restaurante";
            else if (RB_Bar.IsChecked == true)
                t = "bar";
            else { 
                MessageBox.Show("Tem de selecionar o tipo do Servico: (Restaurante ou Bar)");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@tipo", t);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_restbar.ExecuteNonQuery();
                con.Close();
                FillDatagridRestBar();
                MessageBox.Show("O Servico de Restaurante/Bar foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarRestBar(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_UpdateRestBar";
            SqlCommand cmd_restbar = new SqlCommand(CmdString, con);
            cmd_restbar.CommandType = CommandType.StoredProcedure;
            cmd_restbar.Parameters.AddWithValue("@idServico", ID_servico.Text);
            cmd_restbar.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_restbar.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@descricao", TextBox_ID0.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons RestBar
            string t = null;
            if (RB_Rest.IsChecked == true)
                t = "restaurante";
            else if (RB_Bar.IsChecked == true)
                t = "bar";
            else { 
                MessageBox.Show("Tem de selecionar o tipo do Servico: (Restaurante ou Bar)");
                return;
            }
            cmd_restbar.Parameters.AddWithValue("@tipo", t);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_restbar.ExecuteNonQuery();
                con.Close();
                FillDatagridRestBar();
                MessageBox.Show("O Servico de Restaurante/Bar foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void RemoverRestBar(object sender, RoutedEventArgs e)
        {
            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
                && ComboBox_ID_Servico.Text == "" && RB_Rest.IsChecked == false && RB_Bar.IsChecked == false 
                && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text=="" && TextBox_ID0.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
               && RB_Rest.IsChecked == false && RB_Bar.IsChecked == false
               && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text == "" && TextBox_ID0.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteRestBar";
            SqlCommand cmd_restbar = new SqlCommand(CmdString, con);
            cmd_restbar.CommandType = CommandType.StoredProcedure;
            cmd_restbar.Parameters.AddWithValue("@idServico", ID_servico.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_restbar.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridRestBar();
                    /* ----------------------------- */
                    MessageBox.Show("O servico foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /*___________________________________________________________________________________ */
        /*                                                                                    */
        /*                                      RoomServ                                      */
        /*___________________________________________________________________________________ */

        private void FillDatagridRoomServ()
        {
            string CmdString = "SELECT * FROM udf_RoomServ_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("RoomServ");
            sda.Fill(dt);
            roomserv_grid.ItemsSource = dt.DefaultView;
        }

        private void roomserv_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)roomserv_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_servico.Text = search_id;
            string CmdString = "SELECT * FROM udf_RoomServ_DataGrid(@idServico)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idServico", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("RoomServ_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ComboBox_ID_Servico.SelectedIndex = 1;
            Custo_Servico.Text = Convert.ToDecimal(dr["custo"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["data"]);
            Data_Servico.Text = date;
            TextBox_ID1_1.Text = dr["idProduto"].ToString();
            TextBox_ID1_2.Text = dr["hora"].ToString();
            /* --------------------------------------------------------- */
            // ComboBoxes
            ComboBox_Res_Servico.Text = dr["reserva"].ToString();
            ComboBox_Func_Servico.Text = dr["funcionario"].ToString();
        }

        private void AdicionarRoomServ(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID1_1.Text.Length == 0)
            {
                MessageBox.Show("O id do Produto não pode estar por preencher");
                return;
            }

            if (TextBox_ID1_2.Text.Length == 0)
            {
                MessageBox.Show("A hora não pode estar por preencher");
                return;
            }

            string CmdString = "sp_AddRoomServ";
            SqlCommand cmd_roomserv = new SqlCommand(CmdString, con);
            cmd_roomserv.CommandType = CommandType.StoredProcedure;
            cmd_roomserv.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_roomserv.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@idProduto", TextBox_ID1_1.Text);
            try
            {
                var hour = Convert.ToDateTime(TextBox_ID1_2.Text);
                string res = hour.ToString("hh:mm:ss tt", CultureInfo.InvariantCulture);
                cmd_roomserv.Parameters.AddWithValue("@hora", res);
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da hora errado!");
                return;
            }

            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_roomserv.ExecuteNonQuery();
                con.Close();
                FillDatagridRoomServ();
                MessageBox.Show("O Servico de Room Service foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarRoomServ(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID1_1.Text.Length == 0)
            {
                MessageBox.Show("O id do Produto não pode estar por preencher");
                return;
            }

            if (TextBox_ID1_2.Text.Length == 0)
            {
                MessageBox.Show("A hora não pode estar por preencher");
                return;
            }

            string CmdString = "sp_UpdateRoomServ";
            SqlCommand cmd_roomserv = new SqlCommand(CmdString, con);
            cmd_roomserv.CommandType = CommandType.StoredProcedure;
            cmd_roomserv.Parameters.AddWithValue("@idServico", ID_servico.Text);
            cmd_roomserv.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_roomserv.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_roomserv.Parameters.AddWithValue("@idProduto", TextBox_ID1_1.Text);
            try
            {
                var hour = Convert.ToDateTime(TextBox_ID1_2.Text);
                string res = hour.ToString("hh:mm:ss tt", CultureInfo.InvariantCulture);
                cmd_roomserv.Parameters.AddWithValue("@hora", res);
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da hora errado!");
                return;
            }
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_roomserv.ExecuteNonQuery();
                con.Close();
                FillDatagridRoomServ();
                MessageBox.Show("O Servico de Room Service foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverRoomServ(object sender, RoutedEventArgs e)
        {
            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
                && TextBox_ID1_1.Text=="" && TextBox_ID1_2.Text == ""
                && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteRoomServ";
            SqlCommand cmd_roomserv = new SqlCommand(CmdString, con);
            cmd_roomserv.CommandType = CommandType.StoredProcedure;
            cmd_roomserv.Parameters.AddWithValue("@idServico", ID_servico.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_roomserv.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridRoomServ();
                    /* ----------------------------- */
                    MessageBox.Show("O servico foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /*___________________________________________________________________________________ */
        /*                                                                                    */
        /*                                      Estacionamento                                */
        /*___________________________________________________________________________________ */


        private void FillDatagridEst()
        {
            string CmdString = "SELECT * FROM udf_Est_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Estacionamento");
            sda.Fill(dt);
            est_grid.ItemsSource = dt.DefaultView;
        }

        private void est_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)est_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_servico.Text = search_id;
            string CmdString = "SELECT * FROM udf_Est_DataGrid(@idServico)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idServico", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("RoomServ_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ComboBox_ID_Servico.SelectedIndex = 2;
            Custo_Servico.Text = Convert.ToDecimal(dr["custo"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["data"]);
            Data_Servico.Text = date;
            TextBox_ID2_1.Text = dr["lugar"].ToString();
            /* --------------------------------------------------------- */
            // ComboBoxes
            ComboBox_Res_Servico.Text = dr["reserva"].ToString();
            ComboBox_Func_Servico.Text = dr["funcionario"].ToString();
        }


        private void AdicionarEst(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID2_1.Text.Length == 0)
            {
                MessageBox.Show("O lugar não pode estar por preencher");
                return;
            }

            if (TextBox_ID2_1.Text.Length > 5)
            {
                MessageBox.Show("Formato do lugar errado ");
                return;
            }

            string CmdString = "sp_AddEst";
            SqlCommand cmd_est = new SqlCommand(CmdString, con);
            cmd_est.CommandType = CommandType.StoredProcedure;
            cmd_est.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_est.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@lugar", TextBox_ID2_1.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_est.ExecuteNonQuery();
                con.Close();
                FillDatagridEst();
                MessageBox.Show("O Servico de Estacionamento foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarEst(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID2_1.Text.Length == 0)
            {
                MessageBox.Show("O lugar não pode estar por preencher");
                return;
            }

            if (TextBox_ID2_1.Text.Length > 5)
            {
                MessageBox.Show("Formato do lugar errado ");
                return;
            }

            string CmdString = "sp_UpdateEst";
            SqlCommand cmd_est = new SqlCommand(CmdString, con);
            cmd_est.CommandType = CommandType.StoredProcedure;
            cmd_est.Parameters.AddWithValue("@idServico", ID_servico.Text);
            cmd_est.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_est.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_est.Parameters.AddWithValue("@lugar", TextBox_ID2_1.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_est.ExecuteNonQuery();
                con.Close();
                FillDatagridEst();
                MessageBox.Show("O Servico de Estacionamento foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void RemoverEst(object sender, RoutedEventArgs e)
        {
            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
                && TextBox_ID2_1.Text == "" && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteEst";
            SqlCommand cmd_est = new SqlCommand(CmdString, con);
            cmd_est.CommandType = CommandType.StoredProcedure;
            cmd_est.Parameters.AddWithValue("@idServico", ID_servico.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_est.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridEst();
                    /* ----------------------------- */
                    MessageBox.Show("O servico foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /*___________________________________________________________________________________ */
        /*                                                                                    */
        /*                                      Video                                         */
        /*___________________________________________________________________________________ */


        private void FillDatagridVideo()
        {
            string CmdString = "SELECT * FROM udf_Video_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Video");
            sda.Fill(dt);
            video_grid.ItemsSource = dt.DefaultView;
        }

        private void video_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)video_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            ID_servico.Text = search_id;
            string CmdString = "SELECT * FROM udf_Video_DataGrid(@idServico)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idServico", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Video_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ComboBox_ID_Servico.SelectedIndex = 3;
            Custo_Servico.Text = Convert.ToDecimal(dr["custo"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["data"]);
            Data_Servico.Text = date;
            TextBox_ID3_1.Text = dr["idFilme"].ToString();
            TextBox_ID3_2.Text = dr["hora"].ToString();
            /* --------------------------------------------------------- */
            // ComboBoxes
            ComboBox_Res_Servico.Text = dr["reserva"].ToString();
            ComboBox_Func_Servico.Text = dr["funcionario"].ToString();
        }


        private void AdicionarVideo(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID3_1.Text.Length == 0)
            {
                MessageBox.Show("O id do Filme não pode estar por preencher");
                return;
            }

            if (TextBox_ID3_2.Text.Length == 0)
            {
                MessageBox.Show("A hora não pode estar por preencher");
                return;
            }

            string CmdString = "sp_AddVideo";
            SqlCommand cmd_video = new SqlCommand(CmdString, con);
            cmd_video.CommandType = CommandType.StoredProcedure;
            cmd_video.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_video.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@idFilme", TextBox_ID3_1.Text);
            try
            {
                var hour = Convert.ToDateTime(TextBox_ID3_2.Text);
                string res = hour.ToString("hh:mm:ss tt", CultureInfo.InvariantCulture);
                cmd_video.Parameters.AddWithValue("@hora", res);
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da hora errado!");
                return;
            }

            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_video.ExecuteNonQuery();
                con.Close();
                FillDatagridVideo();
                MessageBox.Show("O Servico de Video foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarVideo(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            if (TextBox_ID3_1.Text.Length == 0)
            {
                MessageBox.Show("O id do Filme não pode estar por preencher");
                return;
            }

            if (TextBox_ID3_2.Text.Length == 0)
            {
                MessageBox.Show("A hora não pode estar por preencher");
                return;
            }

            string CmdString = "sp_UpdateVideo";
            SqlCommand cmd_video = new SqlCommand(CmdString, con);
            cmd_video.CommandType = CommandType.StoredProcedure;
            cmd_video.Parameters.AddWithValue("@idServico", ID_servico.Text);
            //
            cmd_video.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);

            try
            {
                cmd_video.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_video.Parameters.AddWithValue("@idFilme", TextBox_ID3_1.Text);
            try
            {
                var hour = Convert.ToDateTime(TextBox_ID3_2.Text);
                string res = hour.ToString("hh:mm:ss tt", CultureInfo.InvariantCulture);
                cmd_video.Parameters.AddWithValue("@hora", res);
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da hora errado!");
                return;
            }
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_video.ExecuteNonQuery();
                con.Close();
                FillDatagridVideo();
                MessageBox.Show("O Servico de Video foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverVideo(object sender, RoutedEventArgs e)
        {
            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
                && TextBox_ID2_1.Text == "" && TextBox_ID3_1.Text == "" && TextBox_ID3_2.Text == ""
                && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteVideo";
            SqlCommand cmd_video = new SqlCommand(CmdString, con);
            cmd_video.CommandType = CommandType.StoredProcedure;
            cmd_video.Parameters.AddWithValue("@idServico", ID_servico.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_video.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridVideo();
                    /* ----------------------------- */
                    MessageBox.Show("O servico foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /*___________________________________________________________________________________ */
        /*                                                                                    */
        /*                                      ServExt                                       */
        /*___________________________________________________________________________________ */


        private void FillDatagridServExt()
        {
            string CmdString = "SELECT * FROM udf_ServExt_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Video");
            sda.Fill(dt);
            servext_grid.ItemsSource = dt.DefaultView;
        }

        private void servext_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)servext_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ID_servico.Text = search_id;
            string CmdString = "SELECT * FROM udf_ServExt_DataGrid(@idServico)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idServico", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("ServExt_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            ComboBox_ID_Servico.SelectedIndex = 4;
            Custo_Servico.Text = Convert.ToDecimal(dr["custo"]).ToString("#.##");
            var date = String.Format("{0:dd/MM/yyyy}", dr["data"]);
            Data_Servico.Text = date;
            TextBox_ID4_2.Text = dr["descricao"].ToString();
            /* --------------------------------------------------------- */
            // ComboBoxes
            ComboBox_Res_Servico.Text = dr["reserva"].ToString();
            ComboBox_Func_Servico.Text = dr["funcionario"].ToString();
            ComboBox_TipoServExt_ID4_1.Text = dr["tipoServicoExt"].ToString();
        }


        private void AdicionarServExt(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_AddServExt";
            SqlCommand cmd_servext = new SqlCommand(CmdString, con);
            cmd_servext.CommandType = CommandType.StoredProcedure;
            cmd_servext.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);
            // ComboBox_Tipo;
            if (ComboBox_TipoServExt_ID4_1.Text == "")
            {
                MessageBox.Show("O tipo de Servico Externo não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@tipoServicoExt", ComboBox_TipoServExt_ID4_1.Text);

            try
            {
                cmd_servext.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@descricao", TextBox_ID4_2.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_servext.ExecuteNonQuery();
                con.Close();
                FillDatagridServExt();
                MessageBox.Show("O Servico Externo foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarServExt(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ComboBox_ID_Servico.Text.Length == 0)
            {
                MessageBox.Show("O tipo de servico não pode estar por selecionar!");
                return;
            }

            if (Custo_Servico.Text.Length == 0)
            {
                MessageBox.Show("O custo não pode estar por preencher!");
                return;
            }

            double i;
            if (!double.TryParse(Custo_Servico.Text, out i))
            {
                MessageBox.Show("O custo tem de ser um número!");
                return;
            }

            if (Data_Servico.Text.Length == 0)
            {
                MessageBox.Show("A data não pode estar por preencher");
                return;
            }

            string CmdString = "sp_UpdateServExt";
            SqlCommand cmd_servext = new SqlCommand(CmdString, con);
            cmd_servext.CommandType = CommandType.StoredProcedure;
            cmd_servext.Parameters.AddWithValue("@idServico", ID_servico.Text);
            cmd_servext.Parameters.AddWithValue("@custo", Convert.ToDouble(Custo_Servico.Text));
            // ComboBox_Reserva;
            if (ComboBox_Res_Servico.Text == "")
            {
                MessageBox.Show("O id da reserva não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@reserva", ComboBox_Res_Servico.Text);
            // ComboBox_Func;
            if (ComboBox_Func_Servico.Text == "")
            {
                MessageBox.Show("O id do funcionário não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@funcionario", ComboBox_Func_Servico.Text);
            // ComboBox_Tipo;
            if (ComboBox_TipoServExt_ID4_1.Text == "")
            {
                MessageBox.Show("O tipo de Servico Externo não pode estar por selecionar!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@tipoServicoExt", ComboBox_TipoServExt_ID4_1.Text);

            try
            {
                cmd_servext.Parameters.AddWithValue("@data", Convert.ToDateTime(Data_Servico.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_servext.Parameters.AddWithValue("@descricao", TextBox_ID4_2.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_servext.ExecuteNonQuery();
                con.Close();
                FillDatagridServExt();
                MessageBox.Show("O Servico Externo foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverServExt(object sender, RoutedEventArgs e)
        {
            if (ID_servico.Text == "" && Custo_Servico.Text == "" && Data_Servico.Text == ""
                && TextBox_ID2_1.Text == "" && TextBox_ID4_2.Text == ""
                && ComboBox_Res_Servico.Text == "" && ComboBox_Func_Servico.Text == "" && ComboBox_TipoServExt_ID4_1.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteServExt";
            SqlCommand cmd_servext = new SqlCommand(CmdString, con);
            cmd_servext.CommandType = CommandType.StoredProcedure;
            cmd_servext.Parameters.AddWithValue("@idServico", ID_servico.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_servext.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparServ();
                    FillDatagridServExt();
                    /* ----------------------------- */
                    MessageBox.Show("O servico foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */

        private void LimparPag_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ID_Pag.Text = "";
            custototal_Pag.Text = "";
            Data_Pag.Text = "";
            Metodo_Pag.Text = "";
            /* -------------------------- */
            ComboBox_Rec_Pag.SelectedIndex = -1;
            ComboBox_Res_Pag.SelectedIndex = -1;
        }

        private void LimparPag()
        {
            //Limpar tudo
            ID_Pag.Text = "";
            custototal_Pag.Text = "";
            Data_Pag.Text = "";
            Metodo_Pag.Text = "";
            /* -------------------------- */
            ComboBox_Rec_Pag.SelectedIndex = -1;
            ComboBox_Res_Pag.SelectedIndex = -1;
        }

        private void LimparServ_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ID_servico.Text = "";
            Custo_Servico.Text = "";
            Data_Servico.Text = "";
            /* -------------------------- */
            ComboBox_Res_Servico.SelectedIndex = -1;
            ComboBox_Func_Servico.SelectedIndex = -1;
            /* -------------------------- */
            RB_Rest.IsChecked = false;
            RB_Bar.IsChecked = false;
            /* -------------------------- */
            TextBox_ID0.Text = "";
            TextBox_ID1_1.Text = "";
            /* -------------------------- */
            TextBox_ID1_2.Text = "";
            TextBox_ID2_1.Text = "";
            /* -------------------------- */
            TextBox_ID3_1.Text = "";
            TextBox_ID3_2.Text = "";
            /* -------------------------- */
            ComboBox_TipoServExt_ID4_1.SelectedIndex = -1;
            TextBox_ID4_2.Text = "";
        }

        private void LimparServ()
        {
            //Limpar tudo
            ID_servico.Text = "";
            Custo_Servico.Text = "";
            Data_Servico.Text = "";
            /* -------------------------- */
            ComboBox_Res_Servico.SelectedIndex = -1;
            ComboBox_Func_Servico.SelectedIndex = -1;
            /* -------------------------- */
            RB_Rest.IsChecked = false;
            RB_Bar.IsChecked = false;
            /* -------------------------- */
            TextBox_ID0.Text = "";
            TextBox_ID1_1.Text = "";
            /* -------------------------- */
            TextBox_ID1_2.Text = "";
            TextBox_ID2_1.Text = "";
            /* -------------------------- */
            TextBox_ID3_1.Text = "";
            TextBox_ID3_2.Text = "";
            /* -------------------------- */
            ComboBox_TipoServExt_ID4_1.SelectedIndex = -1;
            TextBox_ID4_2.Text = "";
        }

        
        private void LimparServGrids()
        {
            restbar_grid.Visibility = Visibility.Hidden;
            roomserv_grid.Visibility = Visibility.Hidden;
            est_grid.Visibility = Visibility.Hidden;
            video_grid.Visibility = Visibility.Hidden;
            servext_grid.Visibility = Visibility.Hidden;
        }

        private void limpar(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            DInicio_Reserva.Text = "";
            DFim_Reserva.Text = "";
            Nr_Pessoas_Reserva.Text = "";
            /* -------------------------- */
            ComboBox_Pensao_Reserva.SelectedIndex = -1;
            ComboBox_Rec_Reserva.SelectedIndex = -1;
            ComboBox_TipoCama_Reserva.SelectedIndex = -1;
            ComboBox_Cliente_Reserva.SelectedIndex = -1;
            ComboBox_Quarto_Reserva.SelectedIndex = -1;
            /* -------------------------- */
            RB_CamaExtra_Sim.IsChecked = false;
            RB_CamaExtra_Nao.IsChecked = false;
            RB_QtCama_1.IsChecked = false;
            RB_QtCama_2.IsChecked = false;
            RB_QtCama_3.IsChecked = false;
            /* -------------------------- */
            TextBox_ID_Reserva.Text = "";
            TextBox_ID_Pag.Text = "";
            /* -------------------------- */
        }

        private void limpar()
        {
            //Limpar tudo
            DInicio_Reserva.Text = "";
            DFim_Reserva.Text = "";
            Nr_Pessoas_Reserva.Text = "";
            /* -------------------------- */
            ComboBox_Pensao_Reserva.SelectedIndex = -1;
            ComboBox_Rec_Reserva.SelectedIndex = -1;
            ComboBox_TipoCama_Reserva.SelectedIndex = -1;
            ComboBox_Cliente_Reserva.SelectedIndex = -1;
            ComboBox_Quarto_Reserva.SelectedIndex = -1;
            /* -------------------------- */
            RB_CamaExtra_Sim.IsChecked = false;
            RB_CamaExtra_Nao.IsChecked = false;
            RB_QtCama_1.IsChecked = false;
            RB_QtCama_2.IsChecked = false;
            RB_QtCama_3.IsChecked = false;
            /* -------------------------- */
            TextBox_ID_Reserva.Text = "";
            TextBox_ID_Pag.Text = "";
            /* -------------------------- */
        }
    
        private void Button_Home(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void LimparBotoes()
        {
            //Limpar Botoes de adicionar, editar e remover
            /* ------------------------------------------------- */
            B_AdicionarRestBar.Visibility = Visibility.Hidden;
            B_AdicionarRoomServ.Visibility = Visibility.Hidden;
            B_AdicionarEst.Visibility = Visibility.Hidden;
            B_AdicionarVideo.Visibility = Visibility.Hidden;
            B_AdicionarServExt.Visibility = Visibility.Hidden;
            /* ------------------------------------------------- */
            B_EditarRestBar.Visibility = Visibility.Hidden;
            B_EditarRoomServ.Visibility = Visibility.Hidden;
            B_EditarEst.Visibility = Visibility.Hidden;
            B_EditarVideo.Visibility = Visibility.Hidden;
            B_EditarServExt.Visibility = Visibility.Hidden;
            /* ------------------------------------------------- */
            B_RemoverRestBar.Visibility = Visibility.Hidden;
            B_RemoverRoomServ.Visibility = Visibility.Hidden;
            B_RemoverEst.Visibility = Visibility.Hidden;
            B_RemoverVideo.Visibility = Visibility.Hidden;
            B_RemoverServExt.Visibility = Visibility.Hidden;
        }

        private void ComboBox_ID_Servico_Hidden()
        {
            /* ################################################# */
            //Right_Grid
            //ID0 - RestauranteBar
            label_ID0_1.Visibility = Visibility.Hidden;
            RB_Rest.Visibility = Visibility.Hidden;
            RB_Bar.Visibility = Visibility.Hidden;
            label_ID0_2.Visibility = Visibility.Hidden;
            TextBox_ID0.Visibility = Visibility.Hidden;
            //ID1 - RoomService
            label_ID1_1.Visibility = Visibility.Hidden;
            TextBox_ID1_1.Visibility = Visibility.Hidden;
            label_ID1_2.Visibility = Visibility.Hidden;
            TextBox_ID1_2.Visibility = Visibility.Hidden;
            //ID2 - Estacionamento
            label_ID2_1.Visibility = Visibility.Hidden;
            TextBox_ID2_1.Visibility = Visibility.Hidden;
            //ID3 - Video
            label_ID3_1.Visibility = Visibility.Hidden;
            TextBox_ID3_1.Visibility = Visibility.Hidden;
            label_ID3_2.Visibility = Visibility.Hidden;
            TextBox_ID3_2.Visibility = Visibility.Hidden;
            //ID4 - ServicoExterno
            label_ID4_1.Visibility = Visibility.Hidden;
            ComboBox_TipoServExt_ID4_1.Visibility = Visibility.Hidden;
            label_ID4_2.Visibility = Visibility.Hidden;
            TextBox_ID4_2.Visibility = Visibility.Hidden;
            /* ################################################# */
            //Grid Botoes_Servicos
            Grid.SetRow(Botoes_Servicos, 5);
        }

        private void ComboBox_ID_Servico_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBox_ID_Servico.SelectedIndex == 0) //RestauranteBar
            {   /* ################################################# */
                //Right_Grid
                ComboBox_ID_Servico_Hidden();
                label_ID0_1.Visibility = Visibility.Visible;
                RB_Rest.Visibility = Visibility.Visible;
                RB_Bar.Visibility = Visibility.Visible;
                label_ID0_2.Visibility = Visibility.Visible;
                TextBox_ID0.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 8);
                Grid.SetRow(Botao_limpar,8);
                /* ################################################# */
                LimparServGrids();
                LimparBotoes();
                /* ################################################# */
                restbar_grid.Visibility = Visibility.Visible;
                B_AdicionarRestBar.Visibility = Visibility.Visible;
                B_EditarRestBar.Visibility = Visibility.Visible;
                B_RemoverRestBar.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridRestBar();
            }
            else if (ComboBox_ID_Servico.SelectedIndex == 1) //RoomService
            {   /* ################################################# */
                //Right_Grid
                ComboBox_ID_Servico_Hidden();
                label_ID1_1.Visibility = Visibility.Visible;
                TextBox_ID1_1.Visibility = Visibility.Visible;
                label_ID1_2.Visibility = Visibility.Visible;
                TextBox_ID1_2.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 8);
                Grid.SetRow(Botao_limpar, 8);
                /* ################################################# */
                LimparServGrids();
                LimparBotoes();
                /* ################################################# */
                roomserv_grid.Visibility = Visibility.Visible;
                B_AdicionarRoomServ.Visibility = Visibility.Visible;
                B_EditarRoomServ.Visibility = Visibility.Visible;
                B_RemoverRoomServ.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridRoomServ();
            }
            else if (ComboBox_ID_Servico.SelectedIndex == 2) //Estacionamento
            {   /* ################################################# */
                //Right_Grid
                ComboBox_ID_Servico_Hidden();
                label_ID2_1.Visibility = Visibility.Visible;
                TextBox_ID2_1.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 7);
                Grid.SetRow(Botao_limpar, 7);
                /* ################################################# */
                LimparServGrids();
                LimparBotoes();
                /* ################################################# */
                est_grid.Visibility = Visibility.Visible;
                B_AdicionarEst.Visibility = Visibility.Visible;
                B_EditarEst.Visibility = Visibility.Visible;
                B_RemoverEst.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridEst();
            }
            else if (ComboBox_ID_Servico.SelectedIndex == 3) //Video
            {
                /* ################################################# */
                //Right_Grid
                ComboBox_ID_Servico_Hidden();
                label_ID3_1.Visibility = Visibility.Visible;
                TextBox_ID3_1.Visibility = Visibility.Visible;
                label_ID3_2.Visibility = Visibility.Visible;
                TextBox_ID3_2.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 8);
                Grid.SetRow(Botao_limpar, 8);
                /* ################################################# */
                LimparServGrids();
                LimparBotoes();
                /* ################################################# */
                video_grid.Visibility = Visibility.Visible;
                B_AdicionarVideo.Visibility = Visibility.Visible;     
                B_EditarVideo.Visibility = Visibility.Visible;
                B_RemoverVideo.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridVideo();
            }
            else if (ComboBox_ID_Servico.SelectedIndex == 4) //ServicoExterno
            {   /* ################################################# */
                ComboBox_ID_Servico_Hidden();
                label_ID4_1.Visibility = Visibility.Visible;
                ComboBox_TipoServExt_ID4_1.Visibility = Visibility.Visible;
                label_ID4_2.Visibility = Visibility.Visible;
                TextBox_ID4_2.Visibility = Visibility.Visible;
                /* ################################################# */
                //Botoes
                Grid.SetRow(Botoes_Servicos, 8);
                Grid.SetRow(Botao_limpar, 8);
                /* ################################################# */
                LimparServGrids();
                LimparBotoes();
                /* ################################################# */
                servext_grid.Visibility = Visibility.Visible;
                B_AdicionarServExt.Visibility = Visibility.Visible;
                B_EditarServExt.Visibility = Visibility.Visible;
                B_RemoverServExt.Visibility = Visibility.Visible;
                /* ################################################# */
                FillDatagridServExt();
            }
        }

        private void RadioButton_CamaExtraSim(object sender, RoutedEventArgs e)
        {
            label_tipoCama_Reserva.Visibility = Visibility.Visible;
            ComboBox_TipoCama_Reserva.Visibility = Visibility.Visible;
            label_QtCama_Reserva.Visibility = Visibility.Visible;
            RB_QtCama_1.Visibility = Visibility.Visible;
            RB_QtCama_2.Visibility = Visibility.Visible;
            RB_QtCama_3.Visibility = Visibility.Visible;
            //Botões
            Grid.SetRow(botoes, 13);
            Grid.SetRow(botao_limpar, 13);
        }

        private void RadioButton_CamaExtraNao(object sender, RoutedEventArgs e)
        {
            label_tipoCama_Reserva.Visibility = Visibility.Hidden;
            ComboBox_TipoCama_Reserva.Visibility = Visibility.Hidden;
            label_QtCama_Reserva.Visibility = Visibility.Hidden;
            RB_QtCama_1.Visibility = Visibility.Hidden;
            RB_QtCama_2.Visibility = Visibility.Hidden;
            RB_QtCama_3.Visibility = Visibility.Hidden;
            //Botões
            Grid.SetRow(botoes, 11);
            Grid.SetRow(botao_limpar, 11);
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            Gestao g = new Gestao();
            this.Close();
            g.ShowDialog();
        }
    }
}
