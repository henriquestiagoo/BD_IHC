﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Hotel.xaml
    /// </summary>
    public partial class Hotel : MetroWindow
    {
        private SqlConnection con;

        public Hotel()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            FillDatagridHoteis();
            FillDatagridTipoQuarto();
            FillDatagridQuarto();
            FillDatagridCama();
        }

        /* ##################################################################################################### */
        /*                                                 Hoteis                                                */
        /* ##################################################################################################### */

        private void FillDatagridHoteis()
        {
            string CmdString = "SELECT * FROM udf_Hotel_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Hotel");
            sda.Fill(dt);
            hoteis_grid.ItemsSource = dt.DefaultView;
            /* ------------------------------------------------------------- */
            //ComboBox Filling
            string CmdString2 = "SELECT DISTINCT nrFuncionario FROM gestaoHotel.Gerente";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Gerente_Hotel.Items.Contains(DR[0]))
                    ComboBox_Gerente_Hotel.Items.Add(DR[0]);
            }
            con.Close();
            /* ------------------------------------------------------------- */
        }


        private void hoteis_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)hoteis_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }

            idHoteis_Hoteis.Text = search_id;
            string CmdString = "SELECT * FROM udf_Hotel_DataGrid(@idHotel)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idHotel", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Hotel_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            idHoteis_Hoteis.Text = dr["idHotel"].ToString();
            Nome_Hoteis.Text = dr["nome"].ToString();
            Morada_Hoteis.Text = dr["localizacao"].ToString();
            CodPostal_Hoteis.Text = dr["codigoPostal"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Classificacao
            if (dr["classificacao"].ToString() == "1")
                RB_1.IsChecked = true;
            else if (dr["classificacao"].ToString() == "2")
                RB_2.IsChecked = true;
            else if (dr["classificacao"].ToString() == "3")
                RB_3.IsChecked = true;
            else if (dr["classificacao"].ToString() == "4")
                RB_4.IsChecked = true;
            else
                RB_5.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Gerente
            ComboBox_Gerente_Hotel.Text = dr["gerente"].ToString();
        }


        private void AdicionarHotel(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Nome_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("O nome do Hotel não pode estar por preencher!");
                return;
            }

            if (Morada_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("A morada do Hotel não pode estar por preencher!");
                return;
            }

            if (CodPostal_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("O código postal do Hotel não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_AddHotel";
            SqlCommand cmd_hotel = new SqlCommand(CmdString, con);
            cmd_hotel.CommandType = CommandType.StoredProcedure;
            cmd_hotel.Parameters.AddWithValue("@nome", Nome_Hoteis.Text);
            cmd_hotel.Parameters.AddWithValue("@localizacao", Morada_Hoteis.Text);
            cmd_hotel.Parameters.AddWithValue("@codigoPostal", CodPostal_Hoteis.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int cl =0;
            if (RB_1.IsChecked == true)
                cl = 1;
            else if (RB_2.IsChecked == true)
                cl = 2;
            else if (RB_3.IsChecked == true)
                cl = 3;
            else if (RB_4.IsChecked == true)
                cl = 4;
            else if (RB_5.IsChecked == true)
                cl = 5;
            else
                MessageBox.Show("A classificação do Hotel não pode estar por preencher!");
            cmd_hotel.Parameters.AddWithValue("@classificacao", cl);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Gerente_Hotel;
            if (ComboBox_Gerente_Hotel.Text == "")
            {
                MessageBox.Show("O gerente do Hotel não pode estar por preencher!");
                return;
            }
            cmd_hotel.Parameters.AddWithValue("@gerente", ComboBox_Gerente_Hotel.Text);

            try
            {
                con.Open();
                cmd_hotel.ExecuteNonQuery();
                con.Close();
                FillDatagridHoteis();
                MessageBox.Show("O Hotel foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarHotel(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (Nome_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("O nome do Hotel não pode estar por preencher!");
                return;
            }

            if (Morada_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("A morada do Hotel não pode estar por preencher!");
                return;
            }

            if (CodPostal_Hoteis.Text.Length == 0)
            {
                MessageBox.Show("O código postal não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_UpdateHotel";
            SqlCommand cmd_hotel = new SqlCommand(CmdString, con);
            cmd_hotel.CommandType = CommandType.StoredProcedure;
            cmd_hotel.Parameters.AddWithValue("@idHotel", idHoteis_Hoteis.Text);
            cmd_hotel.Parameters.AddWithValue("@nome", Nome_Hoteis.Text);
            cmd_hotel.Parameters.AddWithValue("@localizacao", Morada_Hoteis.Text);
            cmd_hotel.Parameters.AddWithValue("@codigoPostal", CodPostal_Hoteis.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int cl = 0;
            if (RB_1.IsChecked == true)
                cl = 1;
            else if (RB_2.IsChecked == true)
                cl = 2;
            else if (RB_3.IsChecked == true)
                cl = 3;
            else if (RB_4.IsChecked == true)
                cl = 4;
            else if (RB_5.IsChecked == true)
                cl = 5;
            else
                MessageBox.Show("A classificação do Hotel não pode estar por preencher!");
            cmd_hotel.Parameters.AddWithValue("@classificacao", cl);
            /* ------------------------------------------------------------------------- */
            // ComboBox_Gerente_Hotel;
            if (ComboBox_Gerente_Hotel.Text == "")
            {
                MessageBox.Show("O gerente do Hotel não pode estar por preencher!");
                return;
            }
            cmd_hotel.Parameters.AddWithValue("@gerente", ComboBox_Gerente_Hotel.Text);

            try
            {
                con.Open();
                cmd_hotel.ExecuteNonQuery();
                con.Close();
                FillDatagridHoteis();
                MessageBox.Show("O hotel foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverHotel(object sender, RoutedEventArgs e)
        {
            if (Nome_Hoteis.Text == "" && Morada_Hoteis.Text == "" && CodPostal_Hoteis.Text == "" 
                && idHoteis_Hoteis.Text == "" && RB_1.IsChecked == false && RB_2.IsChecked == false && RB_3.IsChecked == false
                && RB_4.IsChecked == false && RB_5.IsChecked == false && ComboBox_Gerente_Hotel.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteHotel";
            SqlCommand cmd_hotel = new SqlCommand(CmdString, con);
            cmd_hotel.CommandType = CommandType.StoredProcedure;
            cmd_hotel.Parameters.AddWithValue("@idHotel", idHoteis_Hoteis.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_hotel.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparHotel();
                    FillDatagridHoteis();
                    /* ----------------------------- */
                    MessageBox.Show("O Hotel foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /* ##################################################################################################### */
        /*                                                 TipoQUARTO                                            */
        /* ##################################################################################################### */


        private void FillDatagridTipoQuarto()
        {
            string CmdString = "SELECT * FROM udf_TipoQuarto_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("TipoQuarto");
            sda.Fill(dt);
            tiposquarto_grid.ItemsSource = dt.DefaultView;
            /* ------------------------------------------------------------- */
        }


        private void tiposquarto_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)tiposquarto_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ComboBox_Tipo_Quarto.Text = search_id;
            string CmdString = "SELECT * FROM udf_TipoQuarto_DataGrid(@tipo)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@tipo", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("TipoQuarto_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            Descr_TipoQuarto.Text = dr["descricao"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Camas Extra Disp
            if (dr["numCamasExtraDisp"].ToString() == "0")
                RB_Cama_0.IsChecked = true;
            else if (dr["numCamasExtraDisp"].ToString() == "1")
                RB_Cama_1.IsChecked = true;
            else if (dr["numCamasExtraDisp"].ToString() == "2")
                RB_Cama_2.IsChecked = true;
            else if (dr["numCamasExtraDisp"].ToString() == "3")
                RB_Cama_3.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Tipo Quarto
            if (dr["tipo"].ToString() == "single")
                ComboBox_Tipo_Quarto.SelectedIndex = 0;
            else if (dr["tipo"].ToString() == "double")
                ComboBox_Tipo_Quarto.SelectedIndex = 1;
            if (dr["tipo"].ToString() == "twin")
                ComboBox_Tipo_Quarto.SelectedIndex = 2;
            if (dr["tipo"].ToString() == "mini-suite")
                ComboBox_Tipo_Quarto.SelectedIndex = 3;
            if (dr["tipo"].ToString() == "suite")
                ComboBox_Tipo_Quarto.SelectedIndex = 4;
        }


        private void AdicionarTipoQuarto(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Gerente_Hotel;
            if (ComboBox_Tipo_Quarto.Text == "")
            {
                MessageBox.Show("O tipo de quarto não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_AddTipoQuarto";
            SqlCommand cmd_tipoquarto = new SqlCommand(CmdString, con);
            cmd_tipoquarto.CommandType = CommandType.StoredProcedure;
            cmd_tipoquarto.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Quarto.Text);
            cmd_tipoquarto.Parameters.AddWithValue("@descricao", Descr_TipoQuarto.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int nr = 0;
            if (RB_Cama_0.IsChecked == true)
                nr = 1;
            else if (RB_Cama_1.IsChecked == true)
                nr = 2;
            else if (RB_Cama_2.IsChecked == true)
                nr = 3;
            else if (RB_Cama_3.IsChecked == true)
                nr = 4;
            else
                MessageBox.Show("O número de camas extra não pode estar por preencher!");
            cmd_tipoquarto.Parameters.AddWithValue("@numCamasExtraDisp", nr);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_tipoquarto.ExecuteNonQuery();
                con.Close();
                FillDatagridTipoQuarto();
                MessageBox.Show("O tipo de Quarto foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }


        private void EditarTipoQuarto(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Gerente_Hotel;
            if (ComboBox_Tipo_Quarto.Text == "")
            {
                MessageBox.Show("O tipo de quarto não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_UpdateTipoQuarto";
            SqlCommand cmd_tipoquarto = new SqlCommand(CmdString, con);
            cmd_tipoquarto.CommandType = CommandType.StoredProcedure;
            cmd_tipoquarto.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Quarto.Text);
            cmd_tipoquarto.Parameters.AddWithValue("@descricao", Descr_TipoQuarto.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int nr = 0;
            if (RB_Cama_0.IsChecked == true)
                nr = 0;
            else if (RB_Cama_1.IsChecked == true)
                nr = 1;
            else if (RB_Cama_2.IsChecked == true)
                nr = 2;
            else if (RB_Cama_3.IsChecked == true)
                nr = 3;
            else
                MessageBox.Show("O número de camas extra não pode estar por preencher!");
            cmd_tipoquarto.Parameters.AddWithValue("@numCamasExtraDisp", nr);
            /* ------------------------------------------------------------------------- */            

            try
            {
                con.Open();
                cmd_tipoquarto.ExecuteNonQuery();
                con.Close();
                FillDatagridTipoQuarto();
                MessageBox.Show("O tipo de Quarto foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverTipoQuarto(object sender, RoutedEventArgs e)
        {
            if (ComboBox_Tipo_Quarto.Text == "" && Descr_TipoQuarto.Text == "" && RB_Cama_0.IsChecked == false
                && RB_Cama_1.IsChecked == false && RB_Cama_2.IsChecked == false && RB_Cama_3.IsChecked == false
                && ComboBox_Tipo_Quarto.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteTipoQuarto";
            SqlCommand cmd_tipoquarto = new SqlCommand(CmdString, con);
            cmd_tipoquarto.CommandType = CommandType.StoredProcedure;
            cmd_tipoquarto.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Quarto.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {

                try
                {
                    con.Open();
                    cmd_tipoquarto.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparTipoQuarto();
                    FillDatagridTipoQuarto();
                    /* ----------------------------- */
                    MessageBox.Show("O tipo de Quarto foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                                 QUARTO                                                */
        /* ##################################################################################################### */

        private void FillDatagridQuarto()
        {
            /* ---------------------------------------------------------------- */
            string CmdString = "SELECT * FROM udf_Quarto_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Quarto");
            sda.Fill(dt);
            quartos_grid.ItemsSource = dt.DefaultView;
            /* ---------------------------------------------------------------- */
            //ComboBox Hotel
            string CmdString2 = "SELECT DISTINCT idHotel FROM gestaoHotel.Hotel;";
            SqlCommand cmd2 = new SqlCommand(CmdString2, con);
            con.Open();
            SqlDataReader DR = cmd2.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Hotel_Quarto.Items.Contains(DR[0]))
                    ComboBox_Hotel_Quarto.Items.Add(DR[0]);
            }
            con.Close();
            /* ---------------------------------------------------------------- */
        }

        private void quartos_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ID_Quarto.IsEnabled = false;
            /* ---------------------------------------------------------------- */
            DataRowView row = (DataRowView)quartos_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ID_Quarto.Text = search_id;
            string CmdString = "SELECT * FROM udf_Quarto_DataGrid(@idQuarto)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idQuarto", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Quarto_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            Tel_Quarto.Text = dr["telefone"].ToString();
            /* --------------------------------------------------------- */
            // RadioButtons Fumador
            if (dr["fumador"].ToString() == "1")
                RB_Fumador_Sim.IsChecked = true;
            else if (dr["fumador"].ToString() == "0")
                RB_Fumador_Nao.IsChecked = true;
            // RadioButtons Estado
            if (dr["estado"].ToString() == "1")
                RB_Estado_Ocupado.IsChecked = true;
            else if (dr["estado"].ToString() == "0")
                RB_Estado_Livre.IsChecked = true;
            /* --------------------------------------------------------- */
            // ComboBox Tipo Quarto
            ComboBox_TipoQuarto_Quarto.Text = dr["tipoQuarto"].ToString();
            // ComboBox Hotel
            ComboBox_Hotel_Quarto.Text = dr["hotel"].ToString();
        }

        private void AdicionarQuarto(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ID_Quarto.Text == "")
            {
                MessageBox.Show("O id do quarto não pode estar por preencher!");
                return;
            }
            string CmdString = "sp_AddQuarto";
            SqlCommand cmd_quarto = new SqlCommand(CmdString, con);
            cmd_quarto.CommandType = CommandType.StoredProcedure;
            cmd_quarto.Parameters.AddWithValue("@idQuarto", ID_Quarto.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int fu;
            int es;
            if (RB_Fumador_Sim.IsChecked == true)
                fu = 1;
            else if (RB_Fumador_Nao.IsChecked == true)
                fu = 0;
            else { 
                MessageBox.Show("A informação de fumador não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@fumador", fu);
            //
            if (RB_Estado_Livre.IsChecked == true)
                es = 0;
            else if (RB_Estado_Ocupado.IsChecked == true)
                es = 1;
            else { 
                MessageBox.Show("O estado do quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@estado", es);
            /* ------------------------------------------------------------------------- */
            if (Tel_Quarto.Text == "")
            {
                MessageBox.Show("O telefone do quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@telefone", Tel_Quarto.Text);
            // ComboBox_tipoQuarto;
            if (ComboBox_TipoQuarto_Quarto.Text == "")
            {
                MessageBox.Show("o tipo de quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@tipoQuarto", ComboBox_TipoQuarto_Quarto.Text);
            // ComboBox_hotel;
            if (ComboBox_Hotel_Quarto.Text == "")
            {
                MessageBox.Show("O Hotel não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Quarto.Text);
            try
            {
                con.Open();
                cmd_quarto.ExecuteNonQuery();
                con.Close();
                FillDatagridQuarto();
                MessageBox.Show("O Quarto foi adicionado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarQuarto(object sender, RoutedEventArgs e)
        {
            string CmdString = "sp_UpdateQuarto";
            SqlCommand cmd_quarto = new SqlCommand(CmdString, con);
            cmd_quarto.CommandType = CommandType.StoredProcedure;
            cmd_quarto.Parameters.AddWithValue("@idQuarto", ID_Quarto.Text);
            /* ------------------------------------------------------------------------- */
            // RadioButtons
            int fu = 0;
            int es = 0;
            if (RB_Fumador_Sim.IsChecked == true)
                fu = 1;
            else if (RB_Fumador_Nao.IsChecked == true)
                fu = 0;
            else { 
                MessageBox.Show("A informação de fumador não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@fumador", fu);
            if (RB_Estado_Livre.IsChecked == true)
                es = 0;
            else if (RB_Estado_Ocupado.IsChecked == true)
                es = 1;
            else { 
                MessageBox.Show("O estado do quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@estado", es);
            /* ------------------------------------------------------------------------- */
            if (Tel_Quarto.Text == "")
            {
                MessageBox.Show("O telefone do quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@telefone", Tel_Quarto.Text);
            // ComboBox_tipoQuarto;
            if (ComboBox_TipoQuarto_Quarto.Text == "")
            {
                MessageBox.Show("O tipo de quarto não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@tipoQuarto", ComboBox_TipoQuarto_Quarto.Text);
            // ComboBox_hotel;
            if (ComboBox_Hotel_Quarto.Text == "")
            {
                MessageBox.Show("O Hotel não pode estar por preencher!");
                return;
            }
            cmd_quarto.Parameters.AddWithValue("@hotel", ComboBox_Hotel_Quarto.Text);

            try
            {
                con.Open();
                cmd_quarto.ExecuteNonQuery();
                con.Close();
                FillDatagridQuarto();
                MessageBox.Show("O Quarto foi editado com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverQuarto(object sender, RoutedEventArgs e)
        {
            if (ID_Quarto.Text == "" && RB_Fumador_Sim.IsChecked == false && RB_Fumador_Nao.IsChecked == false
              && RB_Estado_Livre.IsChecked == false && RB_Estado_Ocupado.IsChecked == false && Tel_Quarto.Text == ""
              && ComboBox_TipoQuarto_Quarto.Text == "" && ComboBox_Hotel_Quarto.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteQuarto";
            SqlCommand cmd_quarto = new SqlCommand(CmdString, con);
            cmd_quarto.CommandType = CommandType.StoredProcedure;
            cmd_quarto.Parameters.AddWithValue("@idQuarto", ID_Quarto.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_quarto.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparQuarto();
                    FillDatagridQuarto();
                    /* ----------------------------- */
                    MessageBox.Show("O quarto foi removido com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }


        /* ##################################################################################################### */
        /*                                                 Camas                                                 */
        /* ##################################################################################################### */

        private void FillDatagridCama()
        {
            /* ---------------------------------------------------------------- */
            string CmdString = "SELECT * FROM udf_Cama_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Cama");
            sda.Fill(dt);
            cama_grid.ItemsSource = dt.DefaultView;
        }

        private void camas_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)cama_grid.SelectedItem;
            string bed_type;
            try
            {
                bed_type = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ComboBox_Tipo_Cama.Text = bed_type;
            string CmdString = "SELECT * FROM udf_Cama_DataGrid(@tipo)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@tipo", bed_type);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Cama_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            Preco_Cama.Text = dr["preco"].ToString();
        }


        private void AdicionarCama(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Tipo Cama;
            if (ComboBox_Tipo_Cama.Text == "")
            {
                MessageBox.Show("O tipo de cama não pode estar por preencher!");
                return;
            }

            if (Preco_Cama.Text == "")
            {
                MessageBox.Show("O preço da cama não pode estar por preencher!");
                return;
            }

            string CmdString = "sp_AddCama";
            SqlCommand cmd_cama = new SqlCommand(CmdString, con);
            cmd_cama.CommandType = CommandType.StoredProcedure;
            cmd_cama.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Cama.Text);
            cmd_cama.Parameters.AddWithValue("@preco", Preco_Cama.Text);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_cama.ExecuteNonQuery();
                con.Close();
                FillDatagridCama();
                MessageBox.Show("A cama foi adicionada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarCama(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Tipo Cama;
            if (ComboBox_Tipo_Cama.Text == "")
            {
                MessageBox.Show("The bed type can't be blank!");
                return;
            }

            if (Preco_Cama.Text == "")
            {
                MessageBox.Show("The bed price can't be blank!");
                return;
            }

            string CmdString = "sp_UpdateCama";
            SqlCommand cmd_cama = new SqlCommand(CmdString, con);
            cmd_cama.CommandType = CommandType.StoredProcedure;
            cmd_cama.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Cama.Text);
            cmd_cama.Parameters.AddWithValue("@preco", Preco_Cama.Text);
            /* ------------------------------------------------------------------------- */

            try
            {
                con.Open();
                cmd_cama.ExecuteNonQuery();
                con.Close();
                FillDatagridCama();
                MessageBox.Show("A cama foi editada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverCama(object sender, RoutedEventArgs e)
        {
            if (ComboBox_Tipo_Cama.Text == "" && Preco_Cama.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteCama";
            SqlCommand cmd_cama = new SqlCommand(CmdString, con);
            cmd_cama.CommandType = CommandType.StoredProcedure;
            cmd_cama.Parameters.AddWithValue("@tipo", ComboBox_Tipo_Cama.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_cama.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparCama();
                    FillDatagridCama();
                    /* ----------------------------- */
                    MessageBox.Show("A cama foi removida com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */

        private void Button_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void LimparHotel_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            Nome_Hoteis.Text = "";
            Morada_Hoteis.Text = "";
            CodPostal_Hoteis.Text = "";
            idHoteis_Hoteis.Text = "";
            /* -------------------------- */
            RB_1.IsChecked = false;
            RB_2.IsChecked = false;
            RB_3.IsChecked = false;
            RB_4.IsChecked = false;
            RB_5.IsChecked = false;
            /* -------------------------- */
            ComboBox_Gerente_Hotel.SelectedIndex = -1;
        }

        private void LimparTipoQuarto_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ComboBox_Tipo_Quarto.Text = "";
            Descr_TipoQuarto.Text = "";
            /* -------------------------- */
            RB_Cama_0.IsChecked = false;
            RB_Cama_1.IsChecked = false;
            RB_Cama_2.IsChecked = false;
            RB_Cama_3.IsChecked = false;
            /* -------------------------- */
            ComboBox_Tipo_Quarto.SelectedIndex = -1;
        }

        private void LimparQuarto_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ID_Quarto.Text = "";
            /* -------------------------- */
            RB_Fumador_Nao.IsChecked = false;
            RB_Fumador_Sim.IsChecked = false;
            RB_Estado_Livre.IsChecked = false;
            RB_Estado_Ocupado.IsChecked = false;
            /* -------------------------- */
            Tel_Quarto.Text = "";
            ComboBox_TipoQuarto_Quarto.SelectedIndex = -1;
            ComboBox_Hotel_Quarto.SelectedIndex = -1;
            //
            ID_Quarto.IsEnabled = true;
        }

        private void LimparCama_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            Preco_Cama.Text = "";
            /* -------------------------- */
            ComboBox_Tipo_Cama.SelectedIndex = -1;
        }

        private void LimparHotel()
        {
            //Limpar tudo
            Nome_Hoteis.Text = "";
            Morada_Hoteis.Text = "";
            CodPostal_Hoteis.Text = "";
            idHoteis_Hoteis.Text = "";
            /* -------------------------- */
            RB_1.IsChecked = false;
            RB_2.IsChecked = false;
            RB_3.IsChecked = false;
            RB_4.IsChecked = false;
            RB_5.IsChecked = false;
            /* -------------------------- */
            ComboBox_Gerente_Hotel.SelectedIndex = -1;
        }

        private void LimparTipoQuarto()
        {
            //Limpar tudo
            ComboBox_Tipo_Quarto.Text = "";
            Descr_TipoQuarto.Text = "";
            /* -------------------------- */
            RB_Cama_0.IsChecked = false;
            RB_Cama_1.IsChecked = false;
            RB_Cama_2.IsChecked = false;
            RB_Cama_3.IsChecked = false;
            /* -------------------------- */
            ComboBox_Tipo_Quarto.SelectedIndex = -1;
        }

        private void LimparQuarto(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ID_Quarto.Text = "";
            /* -------------------------- */
            RB_Fumador_Nao.IsChecked = false;
            RB_Fumador_Sim.IsChecked = false;
            RB_Estado_Livre.IsChecked = false;
            RB_Estado_Ocupado.IsChecked = false;
            /* -------------------------- */
            Tel_Quarto.Text = "";
            ComboBox_TipoQuarto_Quarto.SelectedIndex = -1;
            ComboBox_Hotel_Quarto.SelectedIndex = -1;
        }

        private void LimparQuarto()
        {
            //Limpar tudo
            ID_Quarto.Text = "";
            /* -------------------------- */
            RB_Fumador_Nao.IsChecked = false;
            RB_Fumador_Sim.IsChecked = false;
            RB_Estado_Livre.IsChecked = false;
            RB_Estado_Ocupado.IsChecked = false;
            /* -------------------------- */
            Tel_Quarto.Text = "";
            ComboBox_TipoQuarto_Quarto.SelectedIndex = -1;
            ComboBox_Hotel_Quarto.SelectedIndex = -1;
        }

        private void LimparCama()
        {
            //Limpar tudo
            Preco_Cama.Text = "";
            /* -------------------------- */
            ComboBox_Tipo_Cama.SelectedIndex = -1;
        }

        private void Button_Home(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            Gestao g = new Gestao();
            this.Close();
            g.ShowDialog();
        }
    }
}