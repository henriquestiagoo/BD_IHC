﻿using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Data;
using System;

namespace gestaoHotel
{
    
    internal class DBConnection
    {
        private static SqlConnection con;
        static DBConnection()
        {
            string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            con = new SqlConnection(ConnectionString);
        }

        public static SqlConnection getConnection()
        {
            return con;
        }
        
        public static String ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            }
        }
    } 
}

