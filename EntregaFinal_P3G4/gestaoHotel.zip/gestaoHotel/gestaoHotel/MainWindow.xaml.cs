﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        private SqlConnection con;
        public int index=0;

        public MainWindow()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            ComboBox_Fill();
        }

        private void ComboBox_Fill()
        {
            //ComboBox Filling
            string CmdString = "SELECT nome+', '+localizacao FROM gestaoHotel.Hotel;";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            con.Open();
            SqlDataReader DR = cmd.ExecuteReader();
            while (DR.Read())
            {
                if (!ComboBox_Hoteis.Items.Contains(DR[0]))
                    ComboBox_Hoteis.Items.Add(DR[0]);
            }
            con.Close();
        }

        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */     

        private void ComboBox_Hoteis_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            index = ComboBox_Hoteis.SelectedIndex+1;
            Application.Current.Resources["ApplicationScopeResource"] = index;
            DadosPage dp = new DadosPage();
            this.Close();
            dp.ShowDialog();
        }

        private void Button_Login(object sender, RoutedEventArgs e)
        {
            Login login = new Login();   
            login.ShowDialog();
        }

        private void See_Destinations_Click(object sender, RoutedEventArgs e)
        {
            Destinos d = new Destinos();
            this.Close();
            d.ShowDialog();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow m = new MainWindow();
            this.Close();
            m.ShowDialog();
        }       
    }
}
