﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using MahApps.Metro.Controls.Dialogs;
using System.Data.SqlClient;
using System.Data;

namespace gestaoHotel
{
    /// <summary>
    /// Interaction logic for Temporada.xaml
    /// </summary>
    public partial class Temporada : MetroWindow
    {
        private SqlConnection con;

        public Temporada()
        {
            InitializeComponent();
            con = DBConnection.getConnection();
            FillDatagridTemporadas();
            FillDatagridPensoes();
        }

        /* ##################################################################################################### */
        /*                                                 Temporadas                                            */
        /* ##################################################################################################### */

        private void FillDatagridTemporadas()
        {
            string CmdString = "SELECT * FROM udf_Temp_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Temporada");
            sda.Fill(dt);
            temporadas_grid.ItemsSource = dt.DefaultView;        
        }

        private void temporadas_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)temporadas_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            ID_Temporada.Text = search_id;
            string CmdString = "SELECT * FROM udf_Temp_DataGrid(@idTemporada)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@idTemporada", search_id);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Temporada_Data");
            sda.Fill(dt);
            DataRow dr = dt.Rows[0];
            var dataInicio = String.Format("{0:dd/MM/yyyy}", dr["dataComeco"]);
            DInicio_Temp.Text = dataInicio;
            var dataFim = String.Format("{0:dd/MM/yyyy}", dr["dataTermino"]);
            DFim_Temp.Text = dataFim;
            //
            Razao_Temp.Text = dr["razao"].ToString();
            PrecoSimp_Temp.Text = dr["precoSimples"].ToString();
            PrecoD_Temp.Text = dr["precoDouble"].ToString();
            PrecoT_Temp.Text = dr["precoTwin"].ToString();
            PrecoMS_Temp.Text = dr["precoMiniSuite"].ToString();
            PrecoSuite_Temp.Text = dr["precoSuite"].ToString();
        }

        private void AdicionarTemporada(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ID_Temporada.Text.Length == 0)
            {
                MessageBox.Show("O id da Temporada não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(ID_Temporada.Text, out i))
            {
                MessageBox.Show("O id da Temporada tem de ser um número!");
                return;
            }

            if (DInicio_Temp.Text.Length == 0)
            {
                MessageBox.Show("A data de começo da Temporada não pode estar por preencher!");
                return;
            }

            if (DFim_Temp.Text.Length == 0)
            {
                MessageBox.Show("A data de término da Temporada não pode estar por preencher!");
                return;
            }

            if (Razao_Temp.Text.Length == 0)
            {
                MessageBox.Show("A razão/motivo da Temporada não pode estar por preencher!");
                return;
            }

            if (PrecoSimp_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Simples da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoSimp_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Simples da Temporada tem de ser um número!");
                return;
            }

            if (PrecoD_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Duplo da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoD_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Duplo da Temporada tem de ser um número!");
                return;
            }

            if (PrecoT_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Twin da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoT_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Twin da Temporada tem de ser um número!");
                return;
            }

            if (PrecoMS_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Mini-Suite da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoMS_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Mini-Suite da Temporada tem de ser um número!");
                return;
            }

            if (PrecoSuite_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Suite da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoSuite_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Suite da Temporada tem de ser um número!");
                return;
            }

            string CmdString = "sp_AddTemporada";
            SqlCommand cmd_temporada = new SqlCommand(CmdString, con);
            cmd_temporada.CommandType = CommandType.StoredProcedure;
            cmd_temporada.Parameters.AddWithValue("@idTemporada", ID_Temporada.Text);
            try
            {
                cmd_temporada.Parameters.AddWithValue("@dataComeco", Convert.ToDateTime(DInicio_Temp.Text));
                cmd_temporada.Parameters.AddWithValue("@dataTermino", Convert.ToDateTime(DFim_Temp.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_temporada.Parameters.AddWithValue("@razao", Razao_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoSimples", PrecoSimp_Temp.Text);         
            cmd_temporada.Parameters.AddWithValue("@precoDouble", PrecoD_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoTwin", PrecoT_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoMiniSuite", PrecoMS_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoSuite", PrecoSuite_Temp.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_temporada.ExecuteNonQuery();
                con.Close();
                FillDatagridTemporadas();
                MessageBox.Show("A temporada foi adicionada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarTemporada(object sender, RoutedEventArgs e)
        {
            // Validacoes
            if (ID_Temporada.Text.Length == 0)
            {
                MessageBox.Show("O id da Temporada não pode estar por preencher!");
                return;
            }

            int i;
            if (!int.TryParse(ID_Temporada.Text, out i))
            {
                MessageBox.Show("O id da Temporada tem de ser um número!");
                return;
            }

            if (DInicio_Temp.Text.Length == 0)
            {
                MessageBox.Show("A data de começo da Temporada não pode estar por preencher!");
                return;
            }

            if (DFim_Temp.Text.Length == 0)
            {
                MessageBox.Show("A data de término da Temporada não pode estar por preencher!");
                return;
            }

            if (Razao_Temp.Text.Length == 0)
            {
                MessageBox.Show("A razão/motivo da Temporada não pode estar por preencher!");
                return;
            }

            if (PrecoSimp_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Simples da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoSimp_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Simples da Temporada tem de ser um número!");
                return;
            }

            if (PrecoD_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Duplo da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoD_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Duplo da Temporada tem de ser um número!");
                return;
            }

            if (PrecoT_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Twin da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoT_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Twin da Temporada tem de ser um número!");
                return;
            }

            if (PrecoMS_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Mini-Suite da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoMS_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Mini-Suite da Temporada tem de ser um número!");
                return;
            }

            if (PrecoSuite_Temp.Text.Length == 0)
            {
                MessageBox.Show("O preço do quarto Suite da Temporada não pode estar por preencher!");
                return;
            }

            if (!int.TryParse(PrecoSuite_Temp.Text, out i))
            {
                MessageBox.Show("O preço do quarto Suite da Temporada tem de ser um número!");
                return;
            }

            string CmdString = "sp_UpdateTemporada";
            SqlCommand cmd_temporada = new SqlCommand(CmdString, con);
            cmd_temporada.CommandType = CommandType.StoredProcedure;
            cmd_temporada.Parameters.AddWithValue("@idTemporada", ID_Temporada.Text);
            try
            {
                cmd_temporada.Parameters.AddWithValue("@dataComeco", Convert.ToDateTime(DInicio_Temp.Text));
                cmd_temporada.Parameters.AddWithValue("@dataTermino", Convert.ToDateTime(DFim_Temp.Text));
            }
            catch (Exception)
            {
                MessageBox.Show("Formato da data errado!");
                return;
            }
            cmd_temporada.Parameters.AddWithValue("@razao", Razao_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoSimples", PrecoSimp_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoDouble", PrecoD_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoTwin", PrecoT_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoMiniSuite", PrecoMS_Temp.Text);
            cmd_temporada.Parameters.AddWithValue("@precoSuite", PrecoSuite_Temp.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_temporada.ExecuteNonQuery();
                con.Close();
                FillDatagridTemporadas();
                MessageBox.Show("A temporada foi editada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverTemporada(object sender, RoutedEventArgs e)
        {
            if (ID_Temporada.Text == "" && DInicio_Temp.Text == "" && DFim_Temp.Text == "" && Razao_Temp.Text == ""
            && PrecoSimp_Temp.Text == "" && PrecoD_Temp.Text == "" && PrecoT_Temp.Text == "" && PrecoMS_Temp.Text == ""
            && PrecoSuite_Temp.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string CmdString = "sp_DeleteTemporada";
            SqlCommand cmd_temporada = new SqlCommand(CmdString, con);
            cmd_temporada.CommandType = CommandType.StoredProcedure;
            cmd_temporada.Parameters.AddWithValue("@idTemporada", ID_Temporada.Text);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_temporada.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparTemp();
                    FillDatagridTemporadas();
                    /* ----------------------------- */
                    MessageBox.Show("A temporada foi removida com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }

        /* ##################################################################################################### */
        /*                                                 Pensoes                                               */
        /* ##################################################################################################### */

        private void FillDatagridPensoes()
        {
            string CmdString = "SELECT * FROM udf_Pensao_DataGrid(DEFAULT)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Pensao");
            sda.Fill(dt);
            pensoes_grid.ItemsSource = dt.DefaultView;
        }

        private void pensoes_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataRowView row = (DataRowView)pensoes_grid.SelectedItem;
            string search_id;
            try
            {
                search_id = row.Row.ItemArray[0].ToString();
            }
            catch (Exception)
            {
                return;
            }
            if (search_id == "SA")
                Tipo_Pensao.SelectedIndex = 0;
            else if (search_id == "APA")
                Tipo_Pensao.SelectedIndex = 1;
            else
                Tipo_Pensao.SelectedIndex = 2;
            string CmdString = "SELECT * FROM udf_Pensao_DataGrid(@tipo)";
            SqlCommand cmd = new SqlCommand(CmdString, con);
            cmd.Parameters.AddWithValue("@tipo", Tipo_Pensao.Text);
            Desc_Pensao.Text = row.Row.ItemArray[1].ToString();
        }

        private void AdicionarPensao(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Tipo_Pensao
            if (Tipo_Pensao.Text == "")
            {
                MessageBox.Show("O tipo de pensão não pode estar por preencher!");
                return;
            }

            string tipopensao;
            if (Tipo_Pensao.SelectedIndex == 0)
                tipopensao = "SA";
            else if (Tipo_Pensao.SelectedIndex == 1)
                tipopensao = "APA";
            else
                tipopensao = "PC";

            string CmdString = "sp_AddPensao";
            SqlCommand cmd_pensao = new SqlCommand(CmdString, con);
            cmd_pensao.CommandType = CommandType.StoredProcedure;
            cmd_pensao.Parameters.AddWithValue("@tipo", tipopensao);
            cmd_pensao.Parameters.AddWithValue("@descricao", Desc_Pensao.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_pensao.ExecuteNonQuery();
                con.Close();
                FillDatagridPensoes();
                MessageBox.Show("A Pensão foi adicionada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void EditarPensao(object sender, RoutedEventArgs e)
        {
            // Validacoes
            // ComboBox_Tipo_Pensao
            if (Tipo_Pensao.Text == "")
            {
                MessageBox.Show("O tipo de pensão não pode estar por preencher!");
                return;
            }

            string tipopensao;
            if (Tipo_Pensao.SelectedIndex == 0)
                tipopensao = "SA";
            else if (Tipo_Pensao.SelectedIndex == 1)
                tipopensao = "APA";
            else
                tipopensao = "PC";

            string CmdString = "sp_UpdatePensao";
            SqlCommand cmd_pensao = new SqlCommand(CmdString, con);
            cmd_pensao.CommandType = CommandType.StoredProcedure;
            cmd_pensao.Parameters.AddWithValue("@tipo", tipopensao);
            cmd_pensao.Parameters.AddWithValue("@descricao", Desc_Pensao.Text);
            /* ------------------------------------------------------------------------- */
            try
            {
                con.Open();
                cmd_pensao.ExecuteNonQuery();
                con.Close();
                FillDatagridPensoes();
                MessageBox.Show("A Pensão foi editada com sucesso!");
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void RemoverPensao(object sender, RoutedEventArgs e)
        {
            if (Tipo_Pensao.Text == "" && Desc_Pensao.Text == "")
            {
                MessageBox.Show("Tem de selecionar algo para remover!");
                return;
            }

            string tipopensao;
            if (Tipo_Pensao.SelectedIndex == 0)
                tipopensao = "SA";
            else if (Tipo_Pensao.SelectedIndex == 1)
                tipopensao = "APA";
            else
                tipopensao = "PC";

            string CmdString = "sp_DeletePensao";
            SqlCommand cmd_temporada = new SqlCommand(CmdString, con);
            cmd_temporada.CommandType = CommandType.StoredProcedure;
            cmd_temporada.Parameters.AddWithValue("@tipo", tipopensao);

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Tem a certeza que quer remover?", "Confirmação de remoção", System.Windows.MessageBoxButton.YesNo);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                try
                {
                    con.Open();
                    cmd_temporada.ExecuteNonQuery();
                    /* ----------------------------- */
                    con.Close();
                    LimparPensao();
                    FillDatagridPensoes();
                    /* ----------------------------- */
                    MessageBox.Show("A pensão foi removida com sucesso!");
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show(ex.Message);
                }
            }
            else
                return;
        }



        /* ##################################################################################################### */
        /*                                                 Buttons                                               */
        /* ##################################################################################################### */


        private void Button_Home(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void Button_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            this.Close();
            mw.ShowDialog();
        }

        private void LimparTemp_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            ID_Temporada.Text = "";
            DInicio_Temp.Text = "";
            DFim_Temp.Text = "";
            Razao_Temp.Text = "";
            PrecoSimp_Temp.Text = "";
            PrecoD_Temp.Text = "";
            PrecoT_Temp.Text = "";
            PrecoMS_Temp.Text = "";
            PrecoSuite_Temp.Text = "";
        }

        private void LimparTemp()
        {
            //Limpar tudo
            ID_Temporada.Text = "";
            DInicio_Temp.Text = "";
            DFim_Temp.Text = "";
            Razao_Temp.Text = "";
            PrecoSimp_Temp.Text = "";
            PrecoD_Temp.Text = "";
            PrecoT_Temp.Text = "";
            PrecoMS_Temp.Text = "";
            PrecoSuite_Temp.Text = "";
        }

        private void LimparPensao_Click(object sender, RoutedEventArgs e)
        {
            //Limpar tudo
            Tipo_Pensao.SelectedIndex = -1;
            Desc_Pensao.Text = "";
        }

        private void LimparPensao()
        {
            //Limpar tudo
            Tipo_Pensao.SelectedIndex = -1;
            Desc_Pensao.Text = "";
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            Gestao g = new Gestao();
            this.Close();
            g.ShowDialog();
        }
    }
}
